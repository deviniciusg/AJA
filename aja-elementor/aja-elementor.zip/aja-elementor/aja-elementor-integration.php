<?php
/**
 * Plugin Name: AJA Elementor Dynamic Posts Integration
 * Description: Integrates WordPress posts (Publicações, Editais, Portfólio) with Elementor, enabling dynamic queries and independent visual editing.
 * Author: Antigravity / AJA
 * Version: 2.0.0
 */

if (!defined('ABSPATH')) exit;

/**
 * Helper to resolve asset URLs (Theme assets or Uploads)
 */
function aja_get_asset_url($relative_path) {
    $relative_path = ltrim($relative_path, '/');
    if (file_exists(get_template_directory() . '/assets/' . $relative_path)) {
        return get_template_directory_uri() . '/assets/' . $relative_path;
    }
    $upload_dir = wp_upload_dir();
    if (file_exists($upload_dir['basedir'] . '/aja-assets/' . $relative_path)) {
        return $upload_dir['baseurl'] . '/aja-assets/' . $relative_path;
    }
    return home_url('/wp-content/themes/aja-tema/assets/' . $relative_path);
}

/**
 * 1. Register Categories and Subcategories
 */
add_action('init', function() {
    $categories = [
        'portfolio'   => 'Portfólio',
        'editais'     => 'Editais',
        'publicacoes' => 'Publicações'
    ];

    foreach ($categories as $slug => $name) {
        if (!term_exists($slug, 'category')) {
            wp_insert_term($name, 'category', ['slug' => $slug]);
        }
    }

    $portfolio_term = get_term_by('slug', 'portfolio', 'category');
    $parent_id = $portfolio_term ? $portfolio_term->term_id : 0;

    $sub_cats = [
        'advocacia' => 'Advocacia Popular & Coletivos',
        'diretoria' => 'Articulação & Conselho',
        'pesquisa'  => 'Pesquisa & Clínicas Jurídicas',
        'sociedade' => 'Organizações da Sociedade Civil'
    ];

    foreach ($sub_cats as $slug => $name) {
        if (!term_exists($slug, 'category')) {
            wp_insert_term($name, 'category', [
                'slug'   => $slug,
                'parent' => $parent_id
            ]);
        }
    }
});

/**
 * 2. Enqueue Tailwind, Google Fonts & Scripts in Frontend & Elementor Editor
 */
add_action('wp_enqueue_scripts', 'aja_enqueue_elementor_assets', 15);
add_action('elementor/preview/enqueue_styles', 'aja_enqueue_elementor_assets');
add_action('elementor/editor/after_enqueue_scripts', 'aja_enqueue_elementor_assets');

function aja_enqueue_elementor_assets() {
    wp_enqueue_style(
        'google-fonts-epilogue-icons',
        'https://fonts.googleapis.com/css2?family=Epilogue:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200&display=swap',
        [],
        null
    );

    wp_enqueue_script(
        'tailwindcss',
        'https://cdn.tailwindcss.com',
        [],
        '3.4.0',
        false
    );

    // Inline Tailwind Brand Tokens Configuration
    $tw_config = "
    if (typeof tailwind !== 'undefined') {
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        'moss-light': '#6f7740',
                        'on-secondary-container': '#741d1d',
                        'on-tertiary': '#ffffff',
                        'ink-primary': '#202115',
                        'on-secondary-fixed': '#410004',
                        'surface-container': '#ede8e1',
                        'inverse-primary': '#c6ca96',
                        'on-tertiary-container': '#f8be51',
                        'on-error': '#ffffff',
                        'surface-tint': '#5d6136',
                        'on-primary-fixed': '#1a1d00',
                        'surface-container-highest': '#e5e2de',
                        'primary-fixed': '#e3e7b0',
                        'background': '#fcf9f5',
                        'on-secondary': '#ffffff',
                        'inverse-surface': '#31302e',
                        'tertiary-fixed': '#ffdeaa',
                        'outline-variant': '#c8c7b9',
                        'tertiary-container': '#6f4d00',
                        'on-tertiary-fixed': '#271900',
                        'secondary': '#a13e3b',
                        'on-surface-variant': '#47473c',
                        'surface-container-low': '#f5f1eb',
                        'border-subtle': '#e2ded7',
                        'secondary-fixed': '#ffdad7',
                        'surface-container-lowest': '#ffffff',
                        'cyan-accent': '#00d3fc',
                        'secondary-fixed-dim': '#ffb3ae',
                        'surface-container-high': '#ebe8e4',
                        'on-background': '#1c1c1a',
                        'on-primary': '#ffffff',
                        'on-error-container': '#93000a',
                        'outline': '#78786b',
                        'primary': '#3b3f17',
                        'inverse-on-surface': '#f3f0ec',
                        'canvas-paper': '#f7f4f0',
                        'on-secondary-fixed-variant': '#812726',
                        'on-surface': '#1c1c1a',
                        'tertiary': '#513700',
                        'surface-dim': '#dcdad6',
                        'error': '#ba1a1a',
                        'earth-dark': '#431d11',
                        'clay-warm': '#825748',
                        'error-container': '#ffdad6',
                        'on-tertiary-fixed-variant': '#5f4100',
                        'surface': '#fcf9f5',
                        'tertiary-fixed-dim': '#f7bd50',
                        'primary-fixed-dim': '#c6ca96',
                        'primary-container': '#52562c',
                        'river-sky': '#a6bfe2',
                        'secondary-container': '#fe857f',
                        'on-primary-fixed-variant': '#464a21',
                        'on-primary-container': '#c7cb96',
                        'surface-variant': '#e5e2de',
                        'surface-bright': '#fcf9f5'
                    },
                    borderRadius: {
                        'DEFAULT': '0.125rem',
                        'lg': '0.25rem',
                        'xl': '0.5rem',
                        'full': '0.75rem'
                    },
                    spacing: {
                        'space-xl': '3rem',
                        'margin': '3rem',
                        'space-xs': '0.25rem',
                        'space-sm': '0.5rem',
                        'gutter-mobile': '1rem',
                        'space-md': '1rem',
                        'margin-mobile': '1.25rem',
                        'gutter': '1.5rem',
                        'space-lg': '1.75rem'
                    },
                    fontFamily: {
                        'body-lg': ['Epilogue', 'sans-serif'],
                        'body-sm': ['Epilogue', 'sans-serif'],
                        'display-lg': ['Epilogue', 'sans-serif'],
                        'label-lg': ['Epilogue', 'sans-serif'],
                        'label-md': ['Epilogue', 'sans-serif'],
                        'headline-md': ['Epilogue', 'sans-serif'],
                        'display-lg-mobile': ['Epilogue', 'sans-serif'],
                        'headline-lg': ['Epilogue', 'sans-serif'],
                        'title-lg': ['Epilogue', 'sans-serif'],
                        'headline-lg-mobile': ['Epilogue', 'sans-serif'],
                        'body-md': ['Epilogue', 'sans-serif'],
                        'title-md': ['Epilogue', 'sans-serif'],
                        'label-sm': ['Epilogue', 'sans-serif'],
                        'headline-sm': ['Epilogue', 'sans-serif']
                    },
                    fontSize: {
                        'body-lg': ['18px', { lineHeight: '28px', fontWeight: '400' }],
                        'body-sm': ['13px', { lineHeight: '20px', fontWeight: '400' }],
                        'display-lg': ['56px', { lineHeight: '64px', letterSpacing: '-0.03em', fontWeight: '600' }],
                        'label-lg': ['13px', { lineHeight: '18px', letterSpacing: '0.04em', fontWeight: '600' }],
                        'label-md': ['11px', { lineHeight: '16px', letterSpacing: '0.08em', fontWeight: '600' }],
                        'headline-md': ['28px', { lineHeight: '36px', letterSpacing: '-0.01em', fontWeight: '500' }],
                        'display-lg-mobile': ['38px', { lineHeight: '44px', letterSpacing: '-0.02em', fontWeight: '600' }],
                        'headline-lg': ['40px', { lineHeight: '48px', letterSpacing: '-0.02em', fontWeight: '500' }],
                        'title-lg': ['19px', { lineHeight: '26px', fontWeight: '600' }],
                        'headline-lg-mobile': ['30px', { lineHeight: '36px', letterSpacing: '-0.01em', fontWeight: '500' }],
                        'body-md': ['15px', { lineHeight: '24px', fontWeight: '400' }],
                        'title-md': ['17px', { lineHeight: '24px', fontWeight: '500' }],
                        'label-sm': ['10px', { lineHeight: '14px', letterSpacing: '0.1em', fontWeight: '600' }],
                        'headline-sm': ['22px', { lineHeight: '28px', fontWeight: '600' }]
                    }
                }
            }
        };
    }";

    wp_add_inline_script('tailwindcss', $tw_config);

    // Custom CSS for Smooth Scrolling, Hidden Scrollbars and Elementor Image Height Fix
    $custom_css = "
        html, body {
            margin: 0;
            padding: 0;
            scroll-behavior: smooth;
        }
        body {
            overscroll-behavior: none;
            background-color: #fcf9f5;
            color: #1c1c1a;
            font-family: 'Epilogue', sans-serif;
        }
        ::-webkit-scrollbar {
            display: none;
        }

        /* Correção crítica para Elementor: forçar imagens com object-cover / h-full a manter 100% de altura */
        .elementor img.object-cover,
        .elementor img.h-full,
        .elementor .object-cover,
        .elementor .h-full > img,
        img.object-cover {
            height: 100% !important;
            max-width: none !important;
            object-fit: cover !important;
        }

        .hero-bg-cover,
        .elementor .hero-bg-cover {
            position: absolute !important;
            inset: 0 !important;
            width: 100% !important;
            height: 100% !important;
            min-height: 100% !important;
            max-width: none !important;
            object-fit: cover !important;
        }
    ";
    wp_add_inline_style('google-fonts-epilogue-icons', $custom_css);
}

/**
 * 3. Custom Meta Box for Simple Content Management
 */
add_action('add_meta_boxes', function() {
    add_meta_box(
        'aja_post_settings',
        '🌿 Configurações da Publicação / Edital / Portfólio (AJA)',
        'aja_render_post_meta_box',
        'post',
        'normal',
        'high'
    );
});

function aja_render_post_meta_box($post) {
    wp_nonce_field('aja_save_post_settings', 'aja_meta_nonce');

    $badge = get_post_meta($post->ID, '_aja_badge', true);
    $subtitle = get_post_meta($post->ID, '_aja_subtitle', true);
    $location = get_post_meta($post->ID, '_aja_location', true);
    $pdf_url = get_post_meta($post->ID, '_aja_pdf_url', true);
    $featured = get_post_meta($post->ID, '_aja_featured', true);
    ?>
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; padding: 8px 0;">
        <div>
            <label style="display:block; font-weight: 600; margin-bottom: 4px;">🏷️ Badge / Tag Superior:</label>
            <input type="text" name="aja_badge" value="<?php echo esc_attr($badge); ?>" placeholder="Ex: Nota Técnica 04/25, Alto Rio Guamá, Pareceres Técnicos" style="width: 100%; padding: 6px 10px;" />
            <small style="color: #666;">Aparece no canto do card ou acima do título.</small>
        </div>

        <div>
            <label style="display:block; font-weight: 600; margin-bottom: 4px;">💼 Cargo / Subtítulo / Eixo:</label>
            <input type="text" name="aja_subtitle" value="<?php echo esc_attr($subtitle); ?>" placeholder="Ex: Liderança Originária & Conselho, GT 03 Finanças, Coordenação Geral" style="width: 100%; padding: 6px 10px;" />
            <small style="color: #666;">Para Portfólio (cargo) ou Publicações (GT de referência).</small>
        </div>

        <div>
            <label style="display:block; font-weight: 600; margin-bottom: 4px;">📍 Localização / Prazo / Info:</label>
            <input type="text" name="aja_location" value="<?php echo esc_attr($location); ?>" placeholder="Ex: Belém / Pará, Prazo: 30 de Outubro de 2026, Remuneração por projeto" style="width: 100%; padding: 6px 10px;" />
            <small style="color: #666;">Exibido no rodapé do card.</small>
        </div>

        <div>
            <label style="display:block; font-weight: 600; margin-bottom: 4px;">🔗 Link do Documento / PDF / Inscrição:</label>
            <input type="text" name="aja_pdf_url" value="<?php echo esc_attr($pdf_url); ?>" placeholder="https://... ou mailto:..." style="width: 100%; padding: 6px 10px;" />
            <small style="color: #666;">Link para baixar o PDF ou formulário de inscrição.</small>
        </div>
    </div>

    <div style="margin-top: 12px; padding-top: 12px; border-top: 1px solid #eee;">
        <label style="font-weight: 600; cursor: pointer;">
            <input type="checkbox" name="aja_featured" value="1" <?php checked($featured, '1'); ?> />
            ⭐ Destacar no Topo da Seção (Aparece como banner grande em Editais)
        </label>
    </div>
    <?php
}

add_action('save_post', function($post_id) {
    if (!isset($_POST['aja_meta_nonce']) || !wp_verify_nonce($_POST['aja_meta_nonce'], 'aja_save_post_settings')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;

    $fields = ['aja_badge', 'aja_subtitle', 'aja_location', 'aja_pdf_url'];
    foreach ($fields as $field) {
        if (isset($_POST[$field])) {
            update_post_meta($post_id, '_' . $field, sanitize_text_field($_POST[$field]));
        }
    }

    $featured = isset($_POST['aja_featured']) ? '1' : '0';
    update_post_meta($post_id, '_aja_featured', $featured);
});

/**
 * 4. Dynamic Rendering Functions
 */

// A) Portfólio / Membros da Rede Grid
function aja_render_portfolio_grid($limit = 12) {
    $query = new WP_Query([
        'category_name'  => 'portfolio',
        'posts_per_page' => $limit,
        'post_status'    => 'publish',
        'orderby'        => 'date',
        'order'          => 'DESC'
    ]);

    ob_start();
    ?>
    <!-- Network Interactive Tabs Filter -->
    <div class="flex items-center gap-2 overflow-x-auto pb-4 mb-8 text-nowrap" id="network-filter-tabs">
        <button class="network-tab active px-4 py-2 rounded-lg bg-primary text-on-primary font-label-md text-label-md uppercase tracking-wider transition-colors shadow-sm" data-target="all" type="button">Todos os Membros</button>
        <button class="network-tab px-4 py-2 rounded-lg bg-surface-container-lowest border border-border-subtle text-on-surface-variant font-label-md text-label-md uppercase tracking-wider hover:bg-surface-container-high transition-colors shadow-sm" data-target="advocacia" type="button">Advocacia Popular &amp; Coletivos</button>
        <button class="network-tab px-4 py-2 rounded-lg bg-surface-container-lowest border border-border-subtle text-on-surface-variant font-label-md text-label-md uppercase tracking-wider hover:bg-surface-container-high transition-colors shadow-sm" data-target="pesquisa" type="button">Pesquisa &amp; Clínicas Jurídicas</button>
        <button class="network-tab px-4 py-2 rounded-lg bg-surface-container-lowest border border-border-subtle text-on-surface-variant font-label-md text-label-md uppercase tracking-wider hover:bg-surface-container-high transition-colors shadow-sm" data-target="sociedade" type="button">Organizações da Sociedade Civil</button>
        <button class="network-tab px-4 py-2 rounded-lg bg-surface-container-lowest border border-border-subtle text-on-surface-variant font-label-md text-label-md uppercase tracking-wider hover:bg-surface-container-high transition-colors shadow-sm" data-target="diretoria" type="button">Articulação &amp; Conselho</button>
    </div>

    <!-- Grid of Leaders & Nodes -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-gutter mb-space-xl" id="network-cards-container">
        <?php
        if ($query->have_posts()) :
            while ($query->have_posts()) : $query->the_post();
                $id = get_the_ID();
                $badge = get_post_meta($id, '_aja_badge', true);
                $subtitle = get_post_meta($id, '_aja_subtitle', true);
                $location = get_post_meta($id, '_aja_location', true) ?: 'Estado / Região • GT';
                $thumb = get_the_post_thumbnail_url($id, 'large');

                // Determine filter category slug and badge color
                $cats = get_the_category($id);
                $cat_slug = 'all';
                $badge_color = 'text-secondary';
                $default_badge = 'Advocacia Popular';

                foreach ($cats as $c) {
                    if (in_array($c->slug, ['advocacia', 'diretoria', 'pesquisa', 'sociedade'])) {
                        $cat_slug = $c->slug;
                        if ($c->slug === 'advocacia') {
                            $badge_color = 'text-secondary';
                            $default_badge = 'Advocacia Popular';
                        } elseif ($c->slug === 'diretoria') {
                            $badge_color = 'text-primary';
                            $default_badge = 'Articulação & Conselho';
                        } elseif ($c->slug === 'pesquisa') {
                            $badge_color = 'text-moss-light';
                            $default_badge = 'Pesquisa & Clínicas Jurídicas';
                        } elseif ($c->slug === 'sociedade') {
                            $badge_color = 'text-clay-warm';
                            $default_badge = 'Organizações da Sociedade Civil';
                        }
                        break;
                    }
                }

                $badge_text = $badge ?: $default_badge;
                $excerpt = get_the_excerpt() ?: wp_trim_words(get_the_content(), 24);
                ?>
                <div class="network-card bg-surface-container-lowest rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 flex flex-col group border border-border-subtle" data-category="<?php echo esc_attr($cat_slug); ?>">
                    <?php if ($thumb) : ?>
                        <div class="h-56 overflow-hidden relative border-b border-border-subtle">
                            <img alt="<?php echo esc_attr(get_the_title()); ?>" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="<?php echo esc_url($thumb); ?>"/>
                        </div>
                    <?php else : ?>
                        <div class="h-56 bg-surface-container flex flex-col items-center justify-center p-6 text-center border-b border-border-subtle select-none">
                            <span class="material-symbols-outlined text-4xl text-outline mb-1.5 opacity-60">image</span>
                            <span class="font-label-md text-label-md uppercase tracking-wider text-on-surface-variant font-medium">Imagem a ser colocada</span>
                        </div>
                    <?php endif; ?>
                    <div class="p-6 flex flex-col flex-1 justify-between">
                        <div>
                            <span class="font-label-sm text-label-sm <?php echo esc_attr($badge_color); ?> font-bold uppercase tracking-wider"><?php echo esc_html($badge_text); ?></span>
                            <h3 class="font-title-lg text-title-lg text-ink-primary font-bold mt-1"><?php echo esc_html(get_the_title()); ?></h3>
                            <p class="font-body-sm text-body-sm text-on-surface-variant mt-2 leading-relaxed">
                                <?php echo esc_html($excerpt); ?>
                            </p>
                        </div>
                        <div class="flex items-center gap-2 mt-4 pt-4 border-t border-surface-container text-on-surface-variant font-label-sm text-label-sm">
                            <span class="material-symbols-outlined text-[16px] text-primary">location_on</span> <?php echo esc_html($location); ?>
                        </div>
                    </div>
                </div>
                <?php
            endwhile;
            wp_reset_postdata();
        else :
            // Fallback: 4 reference cards from code.html
            ?>
            <!-- Card 1 (Advocacia) -->
            <div class="network-card bg-surface-container-lowest rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 flex flex-col group border border-border-subtle" data-category="advocacia">
                <div class="h-56 bg-surface-container flex flex-col items-center justify-center p-6 text-center border-b border-border-subtle select-none">
                    <span class="material-symbols-outlined text-4xl text-outline mb-1.5 opacity-60">image</span>
                    <span class="font-label-md text-label-md uppercase tracking-wider text-on-surface-variant font-medium">Imagem a ser colocada</span>
                </div>
                <div class="p-6 flex flex-col flex-1 justify-between">
                    <div>
                        <span class="font-label-sm text-label-sm text-secondary font-bold uppercase tracking-wider">Advocacia Popular</span>
                        <h3 class="font-title-lg text-title-lg text-ink-primary font-bold mt-1">Nome do Integrante (Exemplo)</h3>
                        <p class="font-body-sm text-body-sm text-on-surface-variant mt-2 leading-relaxed">
                            Isto é um exemplo. Advocacia popular e defesa de direitos territoriais e comunidades tradicionais na Amazônia.
                        </p>
                    </div>
                    <div class="flex items-center gap-2 mt-4 pt-4 border-t border-surface-container text-on-surface-variant font-label-sm text-label-sm">
                        <span class="material-symbols-outlined text-[16px] text-primary">location_on</span> Estado / Região • GT
                    </div>
                </div>
            </div>

            <!-- Card 2 (Diretoria) -->
            <div class="network-card bg-surface-container-lowest rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 flex flex-col group border border-border-subtle" data-category="diretoria">
                <div class="h-56 bg-surface-container flex flex-col items-center justify-center p-6 text-center border-b border-border-subtle select-none">
                    <span class="material-symbols-outlined text-4xl text-outline mb-1.5 opacity-60">image</span>
                    <span class="font-label-md text-label-md uppercase tracking-wider text-on-surface-variant font-medium">Imagem a ser colocada</span>
                </div>
                <div class="p-6 flex flex-col flex-1 justify-between">
                    <div>
                        <span class="font-label-sm text-label-sm text-primary font-bold uppercase tracking-wider">Articulação &amp; Conselho</span>
                        <h3 class="font-title-lg text-title-lg text-ink-primary font-bold mt-1">Nome do Integrante (Exemplo)</h3>
                        <p class="font-body-sm text-body-sm text-on-surface-variant mt-2 leading-relaxed">
                            Isto é um exemplo. Coordenação executiva e alinhamento estratégico de iniciativas socioambientais na bacia amazônica.
                        </p>
                    </div>
                    <div class="flex items-center gap-2 mt-4 pt-4 border-t border-surface-container text-on-surface-variant font-label-sm text-label-sm">
                        <span class="material-symbols-outlined text-[16px] text-primary">location_on</span> Estado / Região • GT
                    </div>
                </div>
            </div>

            <!-- Card 3 (Pesquisa) -->
            <div class="network-card bg-surface-container-lowest rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 flex flex-col group border border-border-subtle" data-category="pesquisa">
                <div class="h-56 bg-surface-container flex flex-col items-center justify-center p-6 text-center border-b border-border-subtle select-none">
                    <span class="material-symbols-outlined text-4xl text-outline mb-1.5 opacity-60">image</span>
                    <span class="font-label-md text-label-md uppercase tracking-wider text-on-surface-variant font-medium">Imagem a ser colocada</span>
                </div>
                <div class="p-6 flex flex-col flex-1 justify-between">
                    <div>
                        <span class="font-label-sm text-label-sm text-moss-light font-bold uppercase tracking-wider">Pesquisa &amp; Clínicas Jurídicas</span>
                        <h3 class="font-title-lg text-title-lg text-ink-primary font-bold mt-1">Nome da Instituição (Exemplo)</h3>
                        <p class="font-body-sm text-body-sm text-on-surface-variant mt-2 leading-relaxed">
                            Isto é um exemplo. Pesquisa aplicada em clínicas de direitos humanos e monitoramento de políticas socioambientais.
                        </p>
                    </div>
                    <div class="flex items-center gap-2 mt-4 pt-4 border-t border-surface-container text-on-surface-variant font-label-sm text-label-sm">
                        <span class="material-symbols-outlined text-[16px] text-primary">location_on</span> Estado / Região • GT
                    </div>
                </div>
            </div>

            <!-- Card 4 (Sociedade) -->
            <div class="network-card bg-surface-container-lowest rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 flex flex-col group border border-border-subtle" data-category="sociedade">
                <div class="h-56 bg-surface-container flex flex-col items-center justify-center p-6 text-center border-b border-border-subtle select-none">
                    <span class="material-symbols-outlined text-4xl text-outline mb-1.5 opacity-60">image</span>
                    <span class="font-label-md text-label-md uppercase tracking-wider text-on-surface-variant font-medium">Imagem a ser colocada</span>
                </div>
                <div class="p-6 flex flex-col flex-1 justify-between">
                    <div>
                        <span class="font-label-sm text-label-sm text-clay-warm font-bold uppercase tracking-wider">Organizações da Sociedade Civil</span>
                        <h3 class="font-title-lg text-title-lg text-ink-primary font-bold mt-1">Nome da Organização (Exemplo)</h3>
                        <p class="font-body-sm text-body-sm text-on-surface-variant mt-2 leading-relaxed">
                            Isto é um exemplo. Fortalecimento da sociedade civil organizada e incidência jurídica em defesa da floresta em pé.
                        </p>
                    </div>
                    <div class="flex items-center gap-2 mt-4 pt-4 border-t border-surface-container text-on-surface-variant font-label-sm text-label-sm">
                        <span class="material-symbols-outlined text-[16px] text-primary">location_on</span> Estado / Região • GT
                    </div>
                </div>
            </div>
            <?php
        endif;
        ?>
    </div>

    <!-- Script de Filtro Interativo de Abas -->
    <script>
    (function() {
        function initNetworkFilter() {
            var tabs = document.querySelectorAll('#network-filter-tabs .network-tab');
            var cards = document.querySelectorAll('#network-cards-container .network-card');
            if (!tabs.length || !cards.length) return;

            tabs.forEach(function(tab) {
                tab.addEventListener('click', function() {
                    tabs.forEach(function(t) {
                        t.classList.remove('bg-primary', 'text-on-primary', 'active');
                        t.classList.add('bg-surface-container-lowest', 'text-on-surface-variant');
                    });
                    this.classList.add('bg-primary', 'text-on-primary', 'active');
                    this.classList.remove('bg-surface-container-lowest', 'text-on-surface-variant');

                    var target = this.getAttribute('data-target');
                    cards.forEach(function(card) {
                        if (target === 'all' || card.getAttribute('data-category') === target) {
                            card.style.display = 'flex';
                        } else {
                            card.style.display = 'none';
                        }
                    });
                });
            });
        }
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', initNetworkFilter);
        } else {
            initNetworkFilter();
        }
    })();
    </script>
    <?php
    return ob_get_clean();
}

// B) Editais & Submissões Grid
function aja_render_editais_grid() {
    $featured_query = new WP_Query([
        'category_name'  => 'editais',
        'posts_per_page' => 1,
        'post_status'    => 'publish',
        'meta_query'     => [
            [
                'key'     => '_aja_featured',
                'value'   => '1',
                'compare' => '='
            ]
        ]
    ]);

    if (!$featured_query->have_posts()) {
        $featured_query = new WP_Query([
            'category_name'  => 'editais',
            'posts_per_page' => 1,
            'post_status'    => 'publish',
            'orderby'        => 'date',
            'order'          => 'DESC'
        ]);
    }

    $featured_id = 0;
    ob_start();

    if ($featured_query->have_posts()) {
        $featured_query->the_post();
        $featured_id = get_the_ID();
        $badge = get_post_meta($featured_id, '_aja_badge', true) ?: 'Chamada Pública Aberta';
        $location = get_post_meta($featured_id, '_aja_location', true) ?: 'Destinada aos Membros da AJA';
        $pdf_url = get_post_meta($featured_id, '_aja_pdf_url', true) ?: 'mailto:info@ajamazonia.org?subject=Submissao%20de%20Artigo%20AJA';
        $thumb = get_the_post_thumbnail_url($featured_id, 'full') ?: aja_get_asset_url('fotos/corredeira-floresta-pedras.jpg');
        $content = get_the_excerpt() ?: wp_trim_words(get_the_content(), 45);
        ?>
        <!-- Featured Callout Card: CHAMADA PARA SUBMISSÃO DE ARTIGOS -->
        <div class="w-full relative overflow-hidden text-surface-container-lowest rounded-2xl p-8 lg:p-12 mb-8 shadow-sm flex flex-col lg:flex-row justify-between items-start lg:items-center gap-8 group">
            <div class="absolute inset-0 z-0">
                <img alt="<?php echo esc_attr(get_the_title()); ?>" class="w-full h-full object-cover opacity-25 mix-blend-luminosity scale-105 transition-transform duration-700 group-hover:scale-110" src="<?php echo esc_url($thumb); ?>" />
                <div class="absolute inset-0 bg-gradient-to-r from-primary via-primary/95 to-primary-container/90"></div>
            </div>
            <div class="relative z-10 flex flex-col gap-4 max-w-3xl">
                <div class="flex items-center gap-3">
                    <span class="px-3 py-1 rounded bg-tertiary-fixed text-on-tertiary-fixed font-label-sm text-label-sm uppercase tracking-wider font-bold">
                        <?php echo esc_html($badge); ?>
                    </span>
                    <span class="font-label-sm text-label-sm text-primary-fixed-dim"><?php echo esc_html($location); ?></span>
                </div>
                <h3 class="font-headline-md text-headline-md font-bold leading-tight">
                    <?php echo esc_html(get_the_title()); ?>
                </h3>
                <p class="font-body-md text-body-md text-surface-container leading-relaxed">
                    <?php echo esc_html($content); ?>
                </p>
                <div class="flex items-center gap-2 pt-1 text-primary-fixed text-body-sm">
                    <span class="material-symbols-outlined text-[18px]">info</span>
                    <span>Dúvidas sobre a chamada: <strong>info@ajamazonia.org</strong></span>
                </div>
            </div>
            <div class="relative z-10 flex flex-col sm:flex-row items-center gap-4 shrink-0 w-full lg:w-auto">
                <a class="w-full sm:w-auto px-6 py-3.5 rounded-lg bg-surface-container-lowest text-primary hover:bg-surface-container font-label-lg text-label-lg uppercase tracking-wider transition-colors font-bold text-center shadow-md flex items-center justify-center gap-2" href="<?php echo esc_url($pdf_url); ?>" target="_blank" rel="noopener noreferrer">
                    <span>Acessar Edital &amp; Submissão</span>
                    <span class="material-symbols-outlined text-[18px]">download</span>
                </a>
            </div>
        </div>
        <?php
        wp_reset_postdata();
    } else {
        // Fallback banner from code.html
        $banner_bg = aja_get_asset_url('fotos/corredeira-floresta-pedras.jpg');
        ?>
        <div class="w-full relative overflow-hidden text-surface-container-lowest rounded-2xl p-8 lg:p-12 mb-8 shadow-sm flex flex-col lg:flex-row justify-between items-start lg:items-center gap-8 group">
            <div class="absolute inset-0 z-0">
                <img alt="Floresta e corredeiras amazônicas" class="w-full h-full object-cover opacity-25 mix-blend-luminosity scale-105 transition-transform duration-700 group-hover:scale-110" src="<?php echo esc_url($banner_bg); ?>" />
                <div class="absolute inset-0 bg-gradient-to-r from-primary via-primary/95 to-primary-container/90"></div>
            </div>
            <div class="relative z-10 flex flex-col gap-4 max-w-3xl">
                <div class="flex items-center gap-3">
                    <span class="px-3 py-1 rounded bg-tertiary-fixed text-on-tertiary-fixed font-label-sm text-label-sm uppercase tracking-wider font-bold">
                        Chamada Pública Aberta
                    </span>
                    <span class="font-label-sm text-label-sm text-primary-fixed-dim">Destinada aos Membros da AJA</span>
                </div>
                <h3 class="font-headline-md text-headline-md font-bold leading-tight">
                    Chamada para Submissão de Artigos de Opinião Jurídicos
                </h3>
                <p class="font-body-md text-body-md text-surface-container leading-relaxed">
                    A Aliança Jurídica pela Amazônia (AJA) torna pública a chamada para submissão de artigos de opinião jurídicos voltados ao fortalecimento do debate sobre justiça, democracia socioambiental e Estado de Direito na Amazônia.
                </p>
                <div class="flex items-center gap-2 pt-1 text-primary-fixed text-body-sm">
                    <span class="material-symbols-outlined text-[18px]">info</span>
                    <span>Dúvidas sobre a chamada: <strong>info@ajamazonia.org</strong></span>
                </div>
            </div>
            <div class="relative z-10 flex flex-col sm:flex-row items-center gap-4 shrink-0 w-full lg:w-auto">
                <a class="w-full sm:w-auto px-6 py-3.5 rounded-lg bg-surface-container-lowest text-primary hover:bg-surface-container font-label-lg text-label-lg uppercase tracking-wider transition-colors font-bold text-center shadow-md flex items-center justify-center gap-2" href="mailto:info@ajamazonia.org?subject=Submissao%20de%20Artigo%20AJA">
                    <span>Acessar Edital &amp; Submissão</span>
                    <span class="material-symbols-outlined text-[18px]">download</span>
                </a>
            </div>
        </div>
        <?php
    }

    // Secondary Grid
    $secondary_query = new WP_Query([
        'category_name' => 'editais',
        'posts_per_page' => 4,
        'post_status'    => 'publish',
        'post__not_in'   => $featured_id ? [$featured_id] : [],
        'orderby'        => 'date',
        'order'          => 'DESC'
    ]);
    ?>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-gutter">
        <?php
        if ($secondary_query->have_posts()) :
            $sec_idx = 0;
            while ($secondary_query->have_posts()) : $secondary_query->the_post();
                $id = get_the_ID();
                $badge = get_post_meta($id, '_aja_badge', true) ?: ($sec_idx % 2 === 0 ? 'Perícia & Cartografia' : 'Amicus Curiae');
                $location = get_post_meta($id, '_aja_location', true) ?: 'Fluxo Contínuo';
                $subtitle = get_post_meta($id, '_aja_subtitle', true) ?: ($sec_idx % 2 === 0 ? 'Credenciamento de Membros' : 'Avaliação pelo GT 02');
                $pdf_url = get_post_meta($id, '_aja_pdf_url', true) ?: 'mailto:info@ajamazonia.org?subject=' . urlencode('Interesse: ' . get_the_title());
                $badge_bg = ($sec_idx % 2 === 0) ? 'bg-secondary-fixed text-on-secondary-fixed' : 'bg-primary-fixed text-on-primary-fixed';
                $sec_idx++;
                ?>
                <div class="p-8 rounded-xl bg-surface-container-low shadow-sm flex flex-col justify-between border border-border-subtle">
                    <div>
                        <div class="flex items-center justify-between mb-4">
                            <span class="px-2.5 py-1 rounded <?php echo esc_attr($badge_bg); ?> font-label-sm text-label-sm font-semibold uppercase tracking-wider">
                                <?php echo esc_html($badge); ?>
                            </span>
                            <span class="font-label-sm text-label-sm text-on-surface-variant"><?php echo esc_html($location); ?></span>
                        </div>
                        <h4 class="font-title-lg text-title-lg text-ink-primary font-bold mb-2">
                            <?php echo esc_html(get_the_title()); ?>
                        </h4>
                        <p class="font-body-md text-body-md text-on-surface-variant leading-relaxed">
                            <?php echo esc_html(get_the_excerpt() ?: wp_trim_words(get_the_content(), 28)); ?>
                        </p>
                    </div>
                    <div class="mt-6 pt-4 border-t border-surface-container flex items-center justify-between">
                        <span class="font-label-sm text-label-sm text-clay-warm font-semibold"><?php echo esc_html($subtitle); ?></span>
                        <a class="font-label-md text-label-md text-primary font-bold hover:underline inline-flex items-center gap-1" href="<?php echo esc_url($pdf_url); ?>">
                            Manifestar Interesse <span class="material-symbols-outlined text-[16px]">chevron_right</span>
                        </a>
                    </div>
                </div>
                <?php
            endwhile;
            wp_reset_postdata();
        else :
            // Fallback secondary cards from code.html
            ?>
            <div class="p-8 rounded-xl bg-surface-container-low shadow-sm flex flex-col justify-between border border-border-subtle">
                <div>
                    <div class="flex items-center justify-between mb-4">
                        <span class="px-2.5 py-1 rounded bg-secondary-fixed text-on-secondary-fixed font-label-sm text-label-sm font-semibold uppercase tracking-wider">
                            Perícia &amp; Cartografia
                        </span>
                        <span class="font-label-sm text-label-sm text-on-surface-variant">Fluxo Contínuo</span>
                    </div>
                    <h4 class="font-title-lg text-title-lg text-ink-primary font-bold mb-2">
                        Chamada Contínua: Banco de Especialistas em Perícia Ambiental
                    </h4>
                    <p class="font-body-md text-body-md text-on-surface-variant leading-relaxed">
                        Credenciamento de peritos independentes, cartógrafos sociais e antropólogos para auxílio pro bono em laudos técnicos de demarcação territorial, licenciamento e combate a crimes ambientais.
                    </p>
                </div>
                <div class="mt-6 pt-4 border-t border-surface-container flex items-center justify-between">
                    <span class="font-label-sm text-label-sm text-clay-warm font-semibold">Credenciamento de Membros</span>
                    <a class="font-label-md text-label-md text-primary font-bold hover:underline inline-flex items-center gap-1" href="mailto:info@ajamazonia.org?subject=Credenciamento%20Banco%20de%20Especialistas">
                        Manifestar Interesse <span class="material-symbols-outlined text-[16px]">chevron_right</span>
                    </a>
                </div>
            </div>

            <div class="p-8 rounded-xl bg-surface-container-low shadow-sm flex flex-col justify-between border border-border-subtle">
                <div>
                    <div class="flex items-center justify-between mb-4">
                        <span class="px-2.5 py-1 rounded bg-primary-fixed text-on-primary-fixed font-label-sm text-label-sm font-semibold uppercase tracking-wider">
                            Amicus Curiae
                        </span>
                        <span class="font-label-sm text-label-sm text-on-surface-variant">Fluxo Contínuo</span>
                    </div>
                    <h4 class="font-title-lg text-title-lg text-ink-primary font-bold mb-2">
                        Proposição de Teses e Memoriais para Tribunais Superiores
                    </h4>
                    <p class="font-body-md text-body-md text-on-surface-variant leading-relaxed">
                        Envio de memoriais e notas técnicas fundamentadas para validação e submissão conjunta sob a chancela da AJA perante o Supremo Tribunal Federal (STF) e Superior Tribunal de Justiça (STJ).
                    </p>
                </div>
                <div class="mt-6 pt-4 border-t border-surface-container flex items-center justify-between">
                    <span class="font-label-sm text-label-sm text-clay-warm font-semibold">Avaliação pelo GT 02</span>
                    <a class="font-label-md text-label-md text-primary font-bold hover:underline inline-flex items-center gap-1" href="mailto:info@ajamazonia.org?subject=Proposicao%20Amicus%20Curiae%20AJA">
                        Submeter Proposição <span class="material-symbols-outlined text-[16px]">chevron_right</span>
                    </a>
                </div>
            </div>
            <?php
        endif;
        ?>
    </div>
    <?php
    return ob_get_clean();
}

// C) Publicações, Artigos & Notas Técnicas Grid
function aja_render_publicacoes_grid($limit = 6) {
    $query = new WP_Query([
        'category_name'  => 'publicacoes',
        'posts_per_page' => $limit,
        'post_status'    => 'publish',
        'orderby'        => 'date',
        'order'          => 'DESC'
    ]);

    ob_start();
    ?>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-gutter">
        <?php
        if ($query->have_posts()) :
            $idx = 0;
            while ($query->have_posts()) : $query->the_post();
                $id = get_the_ID();
                $badge = get_post_meta($id, '_aja_badge', true);
                $subtitle = get_post_meta($id, '_aja_subtitle', true);
                $pdf_url = get_post_meta($id, '_aja_pdf_url', true) ?: get_permalink();
                $thumb = get_the_post_thumbnail_url($id, 'large');

                if (!$thumb) {
                    $fallback_thumbs = [
                        aja_get_asset_url('fotos/pexels-diego-agudelo-257100874-12577779.jpg'),
                        aja_get_asset_url('fotos/pexels-eduardo-amorim-2155150050-33570703.jpg'),
                        aja_get_asset_url('fotos/pexels-eliezer-nunes-300283905-26146919.jpg')
                    ];
                    $thumb = $fallback_thumbs[$idx % count($fallback_thumbs)];
                }

                $badge_colors = [
                    'text-primary',
                    'text-secondary',
                    'text-earth-dark'
                ];
                $badge_color = $badge_colors[$idx % 3];

                $default_badges = ['Nota Técnica', 'Dossiê Jurídico', 'Guia Prático'];
                $default_gts = ['GT 03 • Finanças Sustentáveis', 'GT 02 • Litigância Estratégica', 'GT 01 • Territórios & PIQCTs'];

                $badge_text = $badge ?: $default_badges[$idx % 3];
                $gt_text = $subtitle ?: $default_gts[$idx % 3];
                $link_labels = ['Ver Parecer', 'Ver Dossiê', 'Ver Manual'];
                $link_label = $link_labels[$idx % 3];

                $excerpt = get_the_excerpt() ?: wp_trim_words(get_the_content(), 24);
                $idx++;
                ?>
                <div class="bg-surface-container-lowest rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow flex flex-col border border-border-subtle group">
                    <div class="h-48 overflow-hidden relative">
                        <img alt="<?php echo esc_attr(get_the_title()); ?>" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="<?php echo esc_url($thumb); ?>"/>
                        <span class="absolute top-3 left-3 px-2 py-0.5 rounded bg-surface-container-lowest/90 backdrop-blur <?php echo esc_attr($badge_color); ?> font-label-sm text-label-sm font-semibold uppercase tracking-wider">
                            <?php echo esc_html($badge_text); ?>
                        </span>
                    </div>
                    <div class="p-6 flex flex-col flex-1 justify-between">
                        <div>
                            <span class="font-label-sm text-label-sm text-on-surface-variant"><?php echo esc_html($gt_text); ?></span>
                            <h3 class="font-title-lg text-title-lg text-ink-primary font-bold mt-2">
                                <a href="<?php echo esc_url(get_permalink()); ?>" class="hover:text-primary transition-colors">
                                    <?php echo esc_html(get_the_title()); ?>
                                </a>
                            </h3>
                            <p class="font-body-sm text-body-sm text-on-surface-variant mt-2 leading-relaxed">
                                <?php echo esc_html($excerpt); ?>
                            </p>
                        </div>
                        <div class="mt-6 pt-4 border-t border-surface-container flex items-center justify-between">
                            <span class="font-label-sm text-label-sm text-clay-warm font-semibold">Produção da Rede</span>
                            <a class="font-label-sm text-label-sm text-primary font-bold hover:underline inline-flex items-center gap-1" href="<?php echo esc_url($pdf_url); ?>">
                                <?php echo esc_html($link_label); ?> <span class="material-symbols-outlined text-[16px]">chevron_right</span>
                            </a>
                        </div>
                    </div>
                </div>
                <?php
            endwhile;
            wp_reset_postdata();
        else :
            // Fallback cards from code.html
            $img1 = aja_get_asset_url('fotos/pexels-diego-agudelo-257100874-12577779.jpg');
            $img2 = aja_get_asset_url('fotos/pexels-eduardo-amorim-2155150050-33570703.jpg');
            $img3 = aja_get_asset_url('fotos/pexels-eliezer-nunes-300283905-26146919.jpg');
            ?>
            <!-- Pub 1 -->
            <div class="bg-surface-container-lowest rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow flex flex-col border border-border-subtle group">
                <div class="h-48 overflow-hidden relative">
                    <img alt="Rio Negro e floresta amazônica" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="<?php echo esc_url($img1); ?>" />
                    <span class="absolute top-3 left-3 px-2 py-0.5 rounded bg-surface-container-lowest/90 backdrop-blur text-primary font-label-sm text-label-sm font-semibold uppercase tracking-wider">
                        Nota Técnica
                    </span>
                </div>
                <div class="p-6 flex flex-col flex-1 justify-between">
                    <div>
                        <span class="font-label-sm text-label-sm text-on-surface-variant">GT 03 • Finanças Sustentáveis</span>
                        <h3 class="font-title-lg text-title-lg text-ink-primary font-bold mt-2">
                            Salvaguardas Mandatórias para Créditos de Carbono Jurisdicionais na Amazônia
                        </h3>
                        <p class="font-body-sm text-body-sm text-on-surface-variant mt-2 leading-relaxed">
                            Análise comparativa das regulações estaduais frente aos padrões internacionais de integridade e direitos territoriais dos povos tradicionais.
                        </p>
                    </div>
                    <div class="mt-6 pt-4 border-t border-surface-container flex items-center justify-between">
                        <span class="font-label-sm text-label-sm text-clay-warm font-semibold">Produção da Rede</span>
                        <a class="font-label-sm text-label-sm text-primary font-bold hover:underline inline-flex items-center gap-1" href="#editais">
                            Ver Parecer <span class="material-symbols-outlined text-[16px]">chevron_right</span>
                        </a>
                    </div>
                </div>
            </div>

            <!-- Pub 2 -->
            <div class="bg-surface-container-lowest rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow flex flex-col border border-border-subtle group">
                <div class="h-48 overflow-hidden relative">
                    <img alt="Floresta primária e raios solares" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="<?php echo esc_url($img2); ?>" />
                    <span class="absolute top-3 left-3 px-2 py-0.5 rounded bg-surface-container-lowest/90 backdrop-blur text-secondary font-label-sm text-label-sm font-semibold uppercase tracking-wider">
                        Dossiê Jurídico
                    </span>
                </div>
                <div class="p-6 flex flex-col flex-1 justify-between">
                    <div>
                        <span class="font-label-sm text-label-sm text-on-surface-variant">GT 02 • Litigância Estratégica</span>
                        <h3 class="font-title-lg text-title-lg text-ink-primary font-bold mt-2">
                            A Litigância Climática Brasileira nos Tribunais Superiores: Mapeamento de Julgados
                        </h3>
                        <p class="font-body-sm text-body-sm text-on-surface-variant mt-2 leading-relaxed">
                            Compilado de acórdãos com teses fixadas sobre prescrição de ilícitos ambientais, recomposição de áreas e tutela preventiva socioecológica.
                        </p>
                    </div>
                    <div class="mt-6 pt-4 border-t border-surface-container flex items-center justify-between">
                        <span class="font-label-sm text-label-sm text-clay-warm font-semibold">Produção da Rede</span>
                        <a class="font-label-sm text-label-sm text-primary font-bold hover:underline inline-flex items-center gap-1" href="#editais">
                            Ver Dossiê <span class="material-symbols-outlined text-[16px]">chevron_right</span>
                        </a>
                    </div>
                </div>
            </div>

            <!-- Pub 3 -->
            <div class="bg-surface-container-lowest rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow flex flex-col border border-border-subtle group">
                <div class="h-48 overflow-hidden relative">
                    <img alt="Canal fluvial natural emoldurado por copas densas de árvores nativas" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" src="<?php echo esc_url($img3); ?>" />
                    <span class="absolute top-3 left-3 px-2 py-0.5 rounded bg-surface-container-lowest/90 backdrop-blur text-earth-dark font-label-sm text-label-sm font-semibold uppercase tracking-wider">
                        Guia Prático
                    </span>
                </div>
                <div class="p-6 flex flex-col flex-1 justify-between">
                    <div>
                        <span class="font-label-sm text-label-sm text-on-surface-variant">GT 01 • Territórios &amp; PIQCTs</span>
                        <h3 class="font-title-lg text-title-lg text-ink-primary font-bold mt-2">
                            Protocolos Autônomos de Consulta: Manual de Redação e Validação Jurídica
                        </h3>
                        <p class="font-body-sm text-body-sm text-on-surface-variant mt-2 leading-relaxed">
                            Instrumento metodológico construído em conjunto com lideranças indígenas para guiar comunidades na formulação de seus próprios protocolos.
                        </p>
                    </div>
                    <div class="mt-6 pt-4 border-t border-surface-container flex items-center justify-between">
                        <span class="font-label-sm text-label-sm text-clay-warm font-semibold">Produção da Rede</span>
                        <a class="font-label-sm text-label-sm text-primary font-bold hover:underline inline-flex items-center gap-1" href="#editais">
                            Ver Manual <span class="material-symbols-outlined text-[16px]">chevron_right</span>
                        </a>
                    </div>
                </div>
            </div>
            <?php
        endif;
        ?>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * 5. Shortcodes
 */
add_shortcode('aja_portfolio', function($atts) {
    $atts = shortcode_atts(['limit' => 12], $atts);
    return aja_render_portfolio_grid((int)$atts['limit']);
});

add_shortcode('aja_editais', function() {
    return aja_render_editais_grid();
});

add_shortcode('aja_publicacoes', function($atts) {
    $atts = shortcode_atts(['limit' => 6], $atts);
    return aja_render_publicacoes_grid((int)$atts['limit']);
});

/**
 * 6. Register Elementor Widgets & Categories
 */
add_action('elementor/elements/categories_registered', function($elements_manager) {
    $elements_manager->add_category(
        'aja-category',
        [
            'title' => '🌿 AJA - Módulos Dinâmicos',
            'icon'  => 'eicon-posts-grid',
        ]
    );
});

add_action('elementor/widgets/register', function($widgets_manager) {

    // Widget 1: Portfólio / Membros da Rede
    class AJA_Elementor_Portfolio extends \Elementor\Widget_Base {
        public function get_name() { return 'aja-portfolio-grid'; }
        public function get_title() { return 'AJA - Portfólio & Mapeamento'; }
        public function get_icon() { return 'eicon-gallery-grid'; }
        public function get_categories() { return ['aja-category', 'general']; }

        protected function register_controls() {
            $this->start_controls_section('content_section', [
                'label' => 'Configurações do Portfólio',
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]);
            $this->add_control('posts_limit', [
                'label'   => 'Quantidade de Membros',
                'type'    => \Elementor\Controls_Manager::NUMBER,
                'min'     => 1,
                'max'     => 36,
                'default' => 12,
            ]);
            $this->end_controls_section();
        }

        protected function render() {
            $settings = $this->get_settings_for_display();
            $limit = !empty($settings['posts_limit']) ? (int)$settings['posts_limit'] : 12;
            echo aja_render_portfolio_grid($limit);
        }
    }

    // Widget 2: Editais & Chamadas
    class AJA_Elementor_Editais extends \Elementor\Widget_Base {
        public function get_name() { return 'aja-editais-grid'; }
        public function get_title() { return 'AJA - Editais & Chamadas'; }
        public function get_icon() { return 'eicon-call-to-action'; }
        public function get_categories() { return ['aja-category', 'general']; }

        protected function render() {
            echo aja_render_editais_grid();
        }
    }

    // Widget 3: Publicações & Notas Técnicas
    class AJA_Elementor_Publicacoes extends \Elementor\Widget_Base {
        public function get_name() { return 'aja-publicacoes-grid'; }
        public function get_title() { return 'AJA - Publicações & Conhecimento'; }
        public function get_icon() { return 'eicon-post-list'; }
        public function get_categories() { return ['aja-category', 'general']; }

        protected function register_controls() {
            $this->start_controls_section('content_section', [
                'label' => 'Configurações de Publicações',
                'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
            ]);
            $this->add_control('posts_limit', [
                'label'   => 'Quantidade de Publicações',
                'type'    => \Elementor\Controls_Manager::NUMBER,
                'min'     => 1,
                'max'     => 24,
                'default' => 6,
            ]);
            $this->end_controls_section();
        }

        protected function render() {
            $settings = $this->get_settings_for_display();
            $limit = !empty($settings['posts_limit']) ? (int)$settings['posts_limit'] : 6;
            echo aja_render_publicacoes_grid($limit);
        }
    }

    $widgets_manager->register(new AJA_Elementor_Portfolio());
    $widgets_manager->register(new AJA_Elementor_Editais());
    $widgets_manager->register(new AJA_Elementor_Publicacoes());
});
