<?php
/**
 * Aliança Jurídica pela Amazônia (AJA) - Página Inicial (Front Page)
 *
 * Configurada para renderizar exatamente o design do code.html,
 * com integração dinâmica para receber postagens de blog em 3 categorias:
 * 1. "portfolio"   -> Seção de Membros e Portfólio de Atuação (#portfolio)
 * 2. "editais"     -> Seção de Editais e Chamadas para Submissão (#editais)
 * 3. "publicacoes" -> Seção de Publicações, Artigos e Notas Técnicas (#conhecimento)
 */

get_header();
?>

<main class="w-full pt-20 bg-surface min-h-[calc(100vh-80px)]">
  <div class="flex flex-col w-full">

    <!-- HERO SECTION: PLATAFORMA DE ARTICULAÇÃO & ESTADO DE DIREITO -->
    <section class="relative w-full overflow-hidden bg-primary -mt-20 pt-28 pb-12 lg:pb-16 min-h-[660px] lg:min-h-[100vh] xl:min-h-[100vh] flex items-center">
      <!-- Background Image with Scrim (Split vertical: Forest on left, Vibrant Amazon Elements Collage on right) -->
      <div class="absolute inset-0 z-0">
        <img alt="Colagem de elementos da Amazônia - Aliança Jurídica pela Amazônia"
          class="w-full h-full object-cover object-[50%_center] lg:object-right"
          src="<?php echo esc_url(aja_asset('homebg.png')); ?>" />
        <!-- Mobile Scrim: Gradiente vertical escuro para máxima legibilidade dos textos -->
        <div class="absolute inset-0 bg-gradient-to-t from-primary/95 via-primary/85 to-primary/50 lg:hidden"></div>
        <!-- Desktop Scrim: Gradiente horizontal da esquerda para a direita -->
        <div class="absolute inset-0 hidden lg:block bg-gradient-to-r from-primary via-primary/75 via-[30%] to-transparent"></div>
      </div>

      <div class="relative z-10 max-w-[1440px] w-full mx-auto px-margin-mobile lg:px-margin my-auto py-8 lg:py-12">
        <!-- Split Grid: Metade esquerda recebe os textos e chamadas; metade direita destaca a colagem -->
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-gutter items-center">
          <!-- Metade da Esquerda (50% / 6 colunas): Textos e Chamadas -->
          <div class="lg:col-span-6 xl:col-span-6 flex flex-col gap-6 max-w-xl xl:max-w-2xl">
            <!-- Header Badge -->
            <div class="flex flex-wrap items-center gap-3">
              <span
                class="inline-flex items-center gap-2 px-3 py-1 bg-surface-container-lowest/15 backdrop-blur-md rounded-lg text-primary-fixed text-label-md font-label-md uppercase tracking-widest border border-white/10">
                <span class="w-2 h-2 rounded-full bg-cyan-accent animate-pulse"></span>
                Plataforma de Articulação Jurídica
              </span>
              <span class="text-surface-container-highest/80 text-label-md font-label-md uppercase tracking-wider">
                Estado de Direito na Amazônia
              </span>
            </div>

            <!-- Main Headline -->
            <h1
              class="font-display-lg text-display-lg-mobile lg:text-[42px] xl:text-display-lg text-surface-container-lowest font-bold tracking-tight leading-[1.12]">
              Fortalecendo o <span class="text-tertiary-fixed font-bold">Estado de Direito</span> na Amazônia Brasileira
            </h1>

            <!-- Subtitle -->
            <p class="font-body-lg text-body-lg text-surface-container leading-relaxed">
              A Aliança Jurídica pela Amazônia (AJA) é uma rede jurídica diversa e representativa que conecta advogados, pesquisadores, organizações da sociedade civil, clínicas de direito e coletivos de base para potencializar a justiça socioambiental, povos e territórios.
            </p>

            <!-- Chamadas & Botões de Ação -->
            <div class="flex flex-wrap items-center gap-4 pt-2">
              <a class="inline-flex items-center justify-center px-6 py-3.5 rounded-lg bg-surface-container-lowest/15 backdrop-blur-md text-surface-container-lowest font-label-lg text-label-lg uppercase tracking-wider transition-all duration-200 hover:bg-surface-container-lowest/25 border border-white/20"
                href="#sobre-nos">
                Conheça a AJA
              </a>
              <a class="inline-flex items-center justify-center px-6 py-3.5 rounded-lg bg-tertiary-fixed text-on-tertiary-fixed font-label-lg text-label-lg uppercase tracking-wider transition-all duration-200 hover:bg-tertiary-fixed-dim hover:shadow-lg font-bold shadow-md"
                href="#faca-parte">
                Faça Parte da Rede
                <span class="material-symbols-outlined ml-2 text-[18px]">arrow_forward</span>
              </a>
              <a class="inline-flex items-center justify-center px-4 py-3.5 rounded-lg text-primary-fixed hover:text-white font-label-lg text-label-lg uppercase tracking-wider transition-colors inline-flex items-center gap-1.5"
                href="#editais">
                <span class="material-symbols-outlined text-[18px]">article</span>
                Chamada de Artigos
              </a>
            </div>
          </div>

          <!-- Metade da Direita (50% / 6 colunas): Colagem Protagonista -->
          <div class="hidden lg:flex lg:col-span-6 xl:col-span-6 items-center justify-end pointer-events-none min-h-[460px] lg:min-h-[560px]">
          </div>
        </div>
      </div>
    </section>

    <!-- INDICADORES DE IMPACTO & ALICERCE TERRITORIAL -->
    <section class="w-full bg-earth-dark text-surface-container-lowest py-10 lg:py-14 relative z-20 shadow-md" id="indicadores">
      <div class="max-w-[1440px] mx-auto px-margin-mobile lg:px-margin">
        <div class="grid grid-cols-2 md:grid-cols-4 gap-6 lg:gap-8">
          <div class="flex flex-col border-l-2 border-tertiary-fixed pl-5">
            <span class="font-display-lg text-[38px] lg:text-[48px] font-bold text-surface-container-lowest leading-none mb-2">3 GTs</span>
            <span class="font-label-md text-label-md text-tertiary-fixed uppercase tracking-wider font-bold">Grupos Temáticos</span>
            <span class="font-body-sm text-body-sm text-surface-container-high mt-1">Território, Litigância Estratégica e Finanças Sustentáveis</span>
          </div>
          <div class="flex flex-col border-l-2 border-cyan-accent pl-5">
            <span class="font-display-lg text-[38px] lg:text-[48px] font-bold text-surface-container-lowest leading-none mb-2">9 Estados</span>
            <span class="font-label-md text-label-md text-cyan-accent uppercase tracking-wider font-bold">Amazônia Legal</span>
            <span class="font-body-sm text-body-sm text-surface-container-high mt-1">Presença nos 9 estados amazônicos com polo de incidência no DF</span>
          </div>
          <div class="flex flex-col border-l-2 border-tertiary-fixed pl-5">
            <span class="font-display-lg text-[38px] lg:text-[48px] font-bold text-surface-container-lowest leading-none mb-2">PIQCTs</span>
            <span class="font-label-md text-label-md text-tertiary-fixed uppercase tracking-wider font-bold">Salvaguardas</span>
            <span class="font-body-sm text-body-sm text-surface-container-high mt-1">Centralidade aos povos indígenas, quilombolas e comunidades</span>
          </div>
          <div class="flex flex-col border-l-2 border-secondary-container pl-5">
            <span class="font-display-lg text-[38px] lg:text-[48px] font-bold text-tertiary-fixed leading-none mb-2">Aliança</span>
            <span class="font-label-md text-label-md text-primary-fixed uppercase tracking-wider font-bold">Rede Articuladora</span>
            <span class="font-body-sm text-body-sm text-surface-container-high mt-1">Espaço plural para advocacia popular, clínicas e sociedade civil</span>
          </div>
        </div>
      </div>
    </section>

    <!-- SECTION 1: SOBRE NÓS (APRESENTAR QUEM SOMOS) -->
    <section class="w-full py-space-xl bg-surface" id="sobre-nos">
      <div class="max-w-[1440px] mx-auto px-margin-mobile lg:px-margin">
        <!-- Section Tagline -->
        <div class="flex items-center gap-3 mb-space-md">
          <span class="w-8 h-[2px] bg-secondary"></span>
          <span class="font-label-md text-label-md text-secondary uppercase tracking-widest font-bold">Apresentar Quem Somos</span>
        </div>

        <!-- Split Editorial Layout -->
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-gutter items-start">
          <!-- Left Column: Manifesto & Narrative -->
          <div class="lg:col-span-7 flex flex-col gap-space-lg">
            <h2 class="font-headline-lg text-headline-lg-mobile lg:text-headline-lg font-medium text-ink-primary leading-tight">
              Uma rede jurídica diversa e representativa pelo fortalecimento do Estado de Direito
            </h2>

            <div class="flex flex-col gap-4 font-body-lg text-body-md text-on-surface-variant max-w-2xl leading-relaxed">
              <p>
                <strong>Aliança Jurídica pela Amazônia (AJA)</strong> é uma rede jurídica diversa e representativa que visa o fortalecimento do Estado de Direito na Amazônia Brasileira, formada por advogados, pesquisadores, organizações da sociedade civil, clínicas de direito, coletivos jurídicos de base e demais profissionais comprometidos com a defesa da justiça socioambiental que atuam na ou pela Amazônia.
              </p>
              <p>
                A AJA atua como um espaço articulador e colaborativo, conectando e potencializando atores e iniciativas já existentes; incentivando o diálogo e a cooperação em temas transversais e valorizando a diversidade de saberes, jurídicos e tradicionais, para enfrentar de forma integrada os desafios da região, contribuindo para a proteção de direitos humanos e socioambientais, e para a segurança jurídica de povos e territórios.
              </p>
              <p>
                Com enfoque no protagonismo amazônida, a AJA busca influenciar mudanças estruturais no ecossistema jurídico e institucional da região, apoiando o fortalecimento das instituições de justiça, da democracia ambiental e da governança territorial, promovendo ações que visam a construção de uma Amazônia mais justa, segura, próspera e regenerativa.
              </p>
            </div>

            <!-- Quote Block -->
            <blockquote class="p-6 bg-surface-container-lowest rounded-xl border-l-4 border-secondary shadow-sm">
              <p class="font-body-lg text-ink-primary italic leading-relaxed">
                "Mais do que uma articulação jurídica, a AJA é um movimento por um futuro no qual a floresta e seus povos tenham voz, proteção e centralidade na formulação das decisões que afetam seus territórios."
              </p>
            </blockquote>
          </div>

          <!-- Right Column: Visual & 3 Central Functions -->
          <div class="lg:col-span-5 flex flex-col gap-6">
            <div class="relative overflow-hidden rounded-xl bg-surface-container-high h-[340px] shadow-md group">
              <img alt="Rio amazônico com floresta e embarcações atracadas na margem"
                class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                src="<?php echo esc_url(aja_asset('fotos/pexels-pok-rie-33563-1009683.jpg')); ?>" />
              <div
                class="absolute inset-0 bg-gradient-to-t from-earth-dark/85 via-earth-dark/30 to-transparent flex flex-col justify-end p-6 text-surface-container-lowest">
                <span class="font-label-sm text-label-sm uppercase tracking-widest text-primary-fixed-dim">Plataforma de Articulação</span>
                <p class="font-title-md text-title-md font-medium mt-1">Conectando saberes jurídicos e tradicionais nos territórios.</p>
              </div>
            </div>

            <!-- 3 Platform Functions Box -->
            <div class="p-6 bg-surface-container rounded-xl flex flex-col gap-4">
              <span class="font-label-md text-label-md uppercase tracking-wider text-primary font-bold">
                As Três Funções da Plataforma
              </span>
              <div class="flex flex-col gap-3 font-body-sm text-body-sm text-on-surface">
                <div class="flex items-start gap-3">
                  <span class="w-6 h-6 rounded-full bg-primary text-on-primary flex items-center justify-center text-xs shrink-0 font-bold mt-0.5">1</span>
                  <div>
                    <strong class="text-ink-primary">Apresentar quem somos:</strong> Missão, história, princípios orientadores e governança horizontal.
                  </div>
                </div>
                <div class="flex items-start gap-3">
                  <span class="w-6 h-6 rounded-full bg-primary text-on-primary flex items-center justify-center text-xs shrink-0 font-bold mt-0.5">2</span>
                  <div>
                    <strong class="text-ink-primary">Dar visibilidade a quem faz parte:</strong> Mapeamento da rede, portfólio de ações, coletivos, clínicas e defensores.
                  </div>
                </div>
                <div class="flex items-start gap-3">
                  <span class="w-6 h-6 rounded-full bg-primary text-on-primary flex items-center justify-center text-xs shrink-0 font-bold mt-0.5">3</span>
                  <div>
                    <strong class="text-ink-primary">Abrir caminhos de engajamento:</strong> Adesão à rede, submissão de artigos, editais e produção coletiva de conhecimento.
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- SECTION 2: NOSSA HISTÓRIA (MEMÓRIA & CONSTRUÇÃO COLETIVA) -->
    <section class="w-full py-space-xl bg-surface-container border-t border-border-subtle" id="historia">
      <div class="max-w-[1440px] mx-auto px-margin-mobile lg:px-margin">
        <div class="flex items-center gap-3 mb-space-md">
          <span class="w-8 h-[2px] bg-primary"></span>
          <span class="font-label-md text-label-md text-primary uppercase tracking-widest font-bold">Origem e Trajetória</span>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-gutter items-start">
          <div class="lg:col-span-5 flex flex-col gap-6">
            <h2 class="font-headline-lg text-headline-lg-mobile lg:text-headline-lg text-ink-primary font-medium leading-tight">
              Nossa História: Da inquietação à construção de uma aliança permanente
            </h2>
            <p class="font-body-md text-body-md text-on-surface-variant leading-relaxed">
              A Aliança Jurídica pela Amazônia (AJA) nasce de uma inquietação compartilhada. Uma inquietação que não surgiu de um único lugar, nem de uma única voz, mas de experiências acumuladas no tempo por profissionais que pesquisam, resistem e atuam com o Direito na Amazônia.
            </p>
            <div class="p-6 bg-surface-container-lowest rounded-xl border border-border-subtle flex flex-col gap-3 shadow-sm">
              <span class="font-label-md text-label-md uppercase tracking-wider text-secondary font-bold">A Pergunta Fundacional</span>
              <p class="font-body-lg text-ink-primary font-medium italic">
                "O que podemos fazer juntos para fortalecer a atuação jurídica no combate a tantos conflitos socioambientais e violações de direitos na Amazônia?"
              </p>
            </div>
            <div class="rounded-xl overflow-hidden shadow-sm">
              <img alt="Floresta primária com densa vegetação"
                class="w-full object-cover"
                src="<?php echo esc_url(aja_asset('fotos/pexels-gustavodenuncio-29759409.jpg')); ?>" />
            </div>
          </div>

          <div class="lg:col-span-7 flex flex-col gap-6 font-body-md text-body-md text-on-surface-variant leading-relaxed">
            <div class="p-6 bg-surface-container-lowest rounded-xl shadow-sm border border-border-subtle flex flex-col gap-4">
              <h3 class="font-title-lg text-title-lg text-ink-primary font-bold">O Diagnóstico Compartilhado e as Assimetrias do Campo</h3>
              <p>
                Antes do seu lançamento, durante a COP 30, a AJA já se manifestava como um diagnóstico compartilhado. Conversas informais e diálogos bilaterais entre advogados, pesquisadoras e organizações que atuam na Amazônia revelavam uma certa recorrência na fragmentação do campo jurídico, na baixa articulação entre diferentes áreas do Direito e na ausência de um espaço capaz de promover convergência estratégica em torno da defesa socioambiental e dos direitos territoriais na região. Essa inquietação não partiu de um único ator, mas de múltiplas trajetórias que se encontravam na percepção de que os desafios amazônicos exigem respostas jurídicas sistêmicas, integradas e de longo prazo.
              </p>
              <p>
                A prática nos territórios evidenciava, também, a necessidade dessa articulação. De um lado, observava-se a pujância da advocacia corporativa privada, estruturada e com alta capacidade de incidência. De outro, observava-se a advocacia voltada à defesa de direitos humanos, ambientais e de povos e comunidades tradicionais marcada por assimetrias profundas de recursos, apoio técnico e proteção institucional. Além disso, a discussão sobre temas estratégicos para o futuro da Amazônia, como restauração ecológica, bioeconomia, financiamento climático e mercados regenerativos, carecem de mais protagonismo e articulação jurídica, limitando a capacidade de incidência em espaços de decisão nacionais e internacionais.
              </p>
            </div>

            <div class="p-6 bg-surface-container-lowest rounded-xl shadow-sm border border-border-subtle flex flex-col gap-4">
              <h3 class="font-title-lg text-title-lg text-ink-primary font-bold">A Janela de Oportunidade e o Processo Coletivo</h3>
              <p>
                Diante desse cenário, um grupo de advogados, pesquisadores e organizações de direitos humanos e ambientais enxergou uma janela de oportunidade política com a realização da COP30 em Belém. A centralidade da Amazônia no debate climático global reforçou a necessidade de garantir uma presença jurídica estratégica, coordenada e alinhada com as lutas dos territórios. Experiências de outros países da Pan-Amazônia, como a Colômbia, já estavam demonstrando que articulações jurídicas bem estruturadas são capazes de influenciar agendas, produzir posicionamentos comuns e ampliar o impacto político da atuação jurídica em contextos multilaterais.
              </p>
              <p>
                Com efeito, em maio de 2025, impulsionado e gerenciado pelo time de “rule of law” da Amazon Investor Coalition, iniciou-se um processo estruturado de construção coletiva da AJA. Pautado por uma metodologia colaborativa, horizontal e plural, durante 7 (sete) meses, mais de 25 profissionais de diferentes áreas do Direito, vinculados a organizações da sociedade civil, coletivos de advocacia popular, entidades de pesquisa acadêmica, escritórios de advocacia e outras frentes de atuação se reuniram para definir propósitos, princípios, formas de governança e estratégias de atuação.
              </p>
            </div>

            <div class="p-6 bg-primary text-surface-container-lowest rounded-xl shadow-sm flex flex-col gap-3">
              <span class="font-label-sm text-label-sm uppercase tracking-widest text-primary-fixed font-bold">O Modelo de Aliança Permanente</span>
              <p class="leading-relaxed">
                Ao longo desse percurso, consolidou-se a compreensão de que a iniciativa deveria se constituir como uma aliança, e não como um projeto isolado ou mesmo uma organização prestadora de serviços. A escolha pelo modelo de aliança reflete uma decisão estratégica: articular atores autônomos, preservar suas identidades institucionais e potencializar, de forma coordenada, as agendas já existentes. A AJA foi concebida como um catalisador político-jurídico, capaz de validar, conectar e amplificar ações, pesquisas e estratégias desenvolvidas por seus membros, fortalecendo sua incidência sistêmica sem centralizar ou substituir iniciativas.
              </p>
              <p class="text-surface-container-high text-body-sm leading-relaxed border-t border-white/20 pt-3">
                Assim, a Aliança Jurídica pela Amazônia se estabelece como um espaço permanente de articulação, diálogo e incidência jurídica, comprometido com a defesa dos direitos humanos, a proteção do bioma amazônico e o fortalecimento das instituições do Sistema de Justiça.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- SECTION 3: ATUAÇÃO (PLENÁRIAS, GRUPOS TEMÁTICOS E PIQCTS) -->
    <section class="w-full py-space-xl bg-surface border-t border-border-subtle" id="atuacao">
      <div class="max-w-[1440px] mx-auto px-margin-mobile lg:px-margin">
        <div class="flex items-center gap-3 mb-2">
          <span class="w-8 h-[2px] bg-secondary"></span>
          <span class="font-label-md text-label-md text-secondary uppercase tracking-widest font-bold">Estrutura Operacional</span>
        </div>
        <div class="flex flex-col md:flex-row md:items-end justify-between mb-space-lg gap-4">
          <div>
            <h2 class="font-headline-lg text-headline-lg-mobile lg:text-headline-lg text-ink-primary font-medium">
              Nossa Atuação: Espaços de Construção Contínua
            </h2>
          </div>
          <p class="font-body-md text-body-md text-on-surface-variant max-w-lg">
            A atuação da AJA é estruturada em espaços de construção contínua: as reuniões plenárias, que reúnem todos os membros para alinhamento estratégico e tomada de decisões coletivas, e os Grupos Temáticos (GTs), que são o coração do trabalho técnico e colaborativo da rede.
          </p>
        </div>

        <!-- Highlight Box: Plenárias & Metodologia -->
        <div class="p-6 lg:p-8 bg-surface-container-lowest rounded-2xl shadow-sm border border-border-subtle mb-10 grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
          <div class="md:col-span-8 flex flex-col gap-3">
            <span class="font-label-sm text-label-sm uppercase tracking-widest text-primary font-bold">Governança Coletiva & Produção Técnica</span>
            <h3 class="font-title-lg text-title-lg text-ink-primary font-bold">Reuniões Plenárias e Grupos Temáticos (GTs)</h3>
            <p class="font-body-md text-body-md text-on-surface-variant leading-relaxed">
              As plenárias reúnem a totalidade de membros para alinhamentos estratégicos horizontais, enquanto os GTs atuam como polos vivos de produção de conhecimento, desenho de estratégias e articulações práticas para responder aos desafios centrais da Amazônia.
            </p>
          </div>
          <div class="md:col-span-4 flex flex-col gap-3 border-t md:border-t-0 md:border-l border-border-subtle pt-4 md:pt-0 md:pl-6">
            <span class="font-label-md text-label-md uppercase tracking-wider text-secondary font-bold">Como Atuar</span>
            <p class="font-body-sm text-body-sm text-on-surface-variant">Membros associados integram um ou mais GTs de acordo com sua área técnica de incidência.</p>
            <a class="font-label-md text-label-md text-primary font-bold hover:text-moss-light inline-flex items-center gap-1 transition-colors" href="#faca-parte">
              Inscrever-se para um GT <span class="material-symbols-outlined text-[16px]">arrow_forward</span>
            </a>
          </div>
        </div>

        <!-- The 3 Thematic Groups (GTs) Cards -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-gutter mb-10">
          <!-- GT 01 -->
          <div class="bg-surface-container-lowest rounded-xl shadow-sm hover:shadow-md transition-all duration-300 flex flex-col justify-between overflow-hidden group border border-border-subtle">
            <div class="flex flex-col">
              <div class="h-48 overflow-hidden relative">
                <img alt="Corredeiras e floresta densa amazônica"
                  class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  src="<?php echo esc_url(aja_asset('fotos/corredeira-floresta-pedras.jpg')); ?>" />
                <div class="absolute inset-0 bg-gradient-to-t from-black/75 via-black/25 to-transparent"></div>
                <span class="absolute top-3 left-3 font-label-sm text-label-sm uppercase tracking-widest px-2.5 py-1 rounded bg-surface-container-lowest/90 backdrop-blur text-earth-dark font-bold shadow-sm">
                  GT 01
                </span>
                <span class="absolute bottom-3 left-3 text-white text-xs font-semibold flex items-center gap-1.5">
                  <span class="material-symbols-outlined text-[16px] text-cyan-accent">terrain</span>
                  Territórios & Segurança
                </span>
              </div>
              <div class="p-6">
                <h3 class="font-title-lg text-title-lg text-ink-primary font-bold mb-3">
                  GT Território, Segurança e Acesso à Justiça
                </h3>
                <p class="font-body-md text-body-md text-on-surface-variant leading-relaxed mb-4">
                  Trabalha a proteção de territórios e populações, com foco em: direitos territoriais, regularização e gestão fundiária, Amazônia urbana, segurança pública, acesso à justiça e combate à crimes ambientais.
                </p>
                <div class="flex flex-wrap gap-1.5">
                  <span class="px-2 py-1 rounded bg-surface-container text-[11px] font-label-sm text-on-surface-variant">Regularização Fundiária</span>
                  <span class="px-2 py-1 rounded bg-surface-container text-[11px] font-label-sm text-on-surface-variant">Crimes Ambientais</span>
                  <span class="px-2 py-1 rounded bg-surface-container text-[11px] font-label-sm text-on-surface-variant">Amazônia Urbana</span>
                </div>
              </div>
            </div>
            <div class="p-6 pt-4 border-t border-surface-container">
              <a class="font-label-lg text-label-lg text-primary hover:text-moss-light inline-flex items-center gap-1 font-semibold group/link"
                href="#faca-parte">
                Integrar este GT
                <span class="material-symbols-outlined text-[16px] group-hover/link:translate-x-1 transition-transform">arrow_forward</span>
              </a>
            </div>
          </div>

          <!-- GT 02 -->
          <div class="bg-surface-container-lowest rounded-xl shadow-sm hover:shadow-md transition-all duration-300 flex flex-col justify-between overflow-hidden group border border-border-subtle">
            <div class="flex flex-col">
              <div class="h-48 overflow-hidden relative">
                <img alt="Navegação em igarapé amazônico com densa cobertura florestal"
                  class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  src="<?php echo esc_url(aja_asset('fotos/pexels-edwin-malca-cerna-1875492332-30302618.jpg')); ?>" />
                <div class="absolute inset-0 bg-gradient-to-t from-black/75 via-black/25 to-transparent"></div>
                <span class="absolute top-3 left-3 font-label-sm text-label-sm uppercase tracking-widest px-2.5 py-1 rounded bg-surface-container-lowest/90 backdrop-blur text-secondary font-bold shadow-sm">
                  GT 02
                </span>
                <span class="absolute bottom-3 left-3 text-white text-xs font-semibold flex items-center gap-1.5">
                  <span class="material-symbols-outlined text-[16px] text-tertiary-fixed">account_balance</span>
                  Incidência Estratégica
                </span>
              </div>
              <div class="p-6">
                <h3 class="font-title-lg text-title-lg text-ink-primary font-bold mb-3">
                  GT Litigância e Ativismo Judicial
                </h3>
                <p class="font-body-md text-body-md text-on-surface-variant leading-relaxed mb-4">
                  Dedica-se ao apoio e desenvolvimento de litígios estratégicos, apoio a casos emblemáticos, monitoramento de julgamentos e incidência estratégica perante o sistema de justiça, com foco nos temas de: justiça climática, direitos difusos e coletivos e democracia ambiental.
                </p>
                <div class="flex flex-wrap gap-1.5">
                  <span class="px-2 py-1 rounded bg-surface-container text-[11px] font-label-sm text-on-surface-variant">Justiça Climática</span>
                  <span class="px-2 py-1 rounded bg-surface-container text-[11px] font-label-sm text-on-surface-variant">Casos Emblemáticos</span>
                  <span class="px-2 py-1 rounded bg-surface-container text-[11px] font-label-sm text-on-surface-variant">STF / STJ</span>
                </div>
              </div>
            </div>
            <div class="p-6 pt-4 border-t border-surface-container">
              <a class="font-label-lg text-label-lg text-primary hover:text-moss-light inline-flex items-center gap-1 font-semibold group/link"
                href="#faca-parte">
                Integrar este GT
                <span class="material-symbols-outlined text-[16px] group-hover/link:translate-x-1 transition-transform">arrow_forward</span>
              </a>
            </div>
          </div>

          <!-- GT 03 -->
          <div class="bg-surface-container-lowest rounded-xl shadow-sm hover:shadow-md transition-all duration-300 flex flex-col justify-between overflow-hidden group border border-border-subtle">
            <div class="flex flex-col">
              <div class="h-48 overflow-hidden relative">
                <img alt="Vitória-régia e sociobiodiversidade amazônica"
                  class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  src="<?php echo esc_url(aja_asset('fotos/vitoria-regia-flora.jpg')); ?>" />
                <div class="absolute inset-0 bg-gradient-to-t from-black/75 via-black/25 to-transparent"></div>
                <span class="absolute top-3 left-3 font-label-sm text-label-sm uppercase tracking-widest px-2.5 py-1 rounded bg-surface-container-lowest/90 backdrop-blur text-primary font-bold shadow-sm">
                  GT 03
                </span>
                <span class="absolute bottom-3 left-3 text-white text-xs font-semibold flex items-center gap-1.5">
                  <span class="material-symbols-outlined text-[16px] text-cyan-accent">forest</span>
                  Sociobiodiversidade
                </span>
              </div>
              <div class="p-6">
                <h3 class="font-title-lg text-title-lg text-ink-primary font-bold mb-3">
                  GT Finanças Sustentáveis e Economias da Sociobiodiversidade
                </h3>
                <p class="font-body-md text-body-md text-on-surface-variant leading-relaxed mb-4">
                  Dedica-se a discutir salvaguardas relacionadas ao direito intelectual e cultural associado à sociobiodiversidade da Amazônia, promoção de negócios justos, uso ético da biodiversidade e do conhecimento tradicional, parâmetros jurídicos para desenvolvimento das economias da sociobiodiversidade e Bens Ambientais.
                </p>
                <div class="flex flex-wrap gap-1.5">
                  <span class="px-2 py-1 rounded bg-surface-container text-[11px] font-label-sm text-on-surface-variant">Conhecimento Tradicional</span>
                  <span class="px-2 py-1 rounded bg-surface-container text-[11px] font-label-sm text-on-surface-variant">Negócios Justos</span>
                  <span class="px-2 py-1 rounded bg-surface-container text-[11px] font-label-sm text-on-surface-variant">Bens Ambientais</span>
                </div>
              </div>
            </div>
            <div class="p-6 pt-4 border-t border-surface-container">
              <a class="font-label-lg text-label-lg text-primary hover:text-moss-light inline-flex items-center gap-1 font-semibold group/link"
                href="#faca-parte">
                Integrar este GT
                <span class="material-symbols-outlined text-[16px] group-hover/link:translate-x-1 transition-transform">arrow_forward</span>
              </a>
            </div>
          </div>
        </div>

        <!-- TRANSVERSALIDADE PIQCTS (DESTAQUE INEGOCIÁVEL) -->
        <div class="w-full bg-surface-container-low rounded-2xl p-8 lg:p-10 border-2 border-primary/20 shadow-sm flex flex-col md:flex-row items-center gap-8">
          <div class="w-16 h-16 rounded-2xl bg-primary text-surface-container-lowest flex items-center justify-center shrink-0 shadow-md">
            <span class="material-symbols-outlined text-[36px]">group_work</span>
          </div>
          <div class="flex flex-col gap-2 flex-1">
            <span class="font-label-sm text-label-sm uppercase tracking-widest text-secondary font-bold">
              Abordagem Transversal Obrigatória
            </span>
            <h3 class="font-title-lg text-title-lg text-ink-primary font-bold">
              Defesa dos Direitos Humanos e Observância aos Direitos dos PIQCTs
            </h3>
            <p class="font-body-md text-body-md text-on-surface-variant leading-relaxed">
              Todos os grupos de trabalho adotam uma abordagem transversal de defesa aos Direitos Humanos, garantindo observância aos direitos dos povos indígenas, quilombolas e comunidades tradicionais (PIQCTs) nas discussões e decisões de cada GT — colocando a Amazônia no centro, e não na margem, das soluções jurídicas e institucionais.
            </p>
          </div>
        </div>
      </div>
    </section>

    <!-- TRANSIÇÃO FOTOGRÁFICA: BACIA HIDROGRÁFICA E FLORESTA AMAZÔNICA -->
    <div class="relative w-full h-64 sm:h-80 md:h-96 lg:h-[420px] overflow-hidden border-t border-border-subtle bg-earth-dark group">
      <img alt="Vista aérea de rio serpenteando pela floresta amazônica até a linha do horizonte urbano"
        class="w-full h-full object-cover object-center transform transition-transform duration-700 ease-out"
        src="<?php echo esc_url(aja_asset('fotos/pexels-japy-14261741.jpg')); ?>" />
      <div class="absolute inset-0 bg-gradient-to-b from-black/10 via-transparent to-black/20 pointer-events-none"></div>
    </div>

    <!-- ========================================================================= -->
    <!-- SECTION 4: QUEM FAZ PARTE & PORTFÓLIO DA REDE (CATEGORIA 1: "portfolio")  -->
    <!-- ========================================================================= -->
    <section class="w-full py-space-xl bg-surface-container border-t border-border-subtle" id="portfolio">
      <div class="max-w-[1440px] mx-auto px-margin-mobile lg:px-margin">
        <!-- Section Header -->
        <div class="flex items-center gap-3 mb-2">
          <span class="w-8 h-[2px] bg-primary"></span>
          <span class="font-label-md text-label-md text-primary uppercase tracking-widest font-bold">Dar Visibilidade a Quem Faz Parte</span>
        </div>
        <div class="flex flex-col md:flex-row md:items-end justify-between mb-space-lg gap-4">
          <div>
            <h2 class="font-headline-lg text-headline-lg-mobile lg:text-headline-lg text-ink-primary font-medium">
              Membros da Rede & Portfólio de Atuação
            </h2>
          </div>
          <p class="font-body-md text-body-md text-on-surface-variant max-w-md">
            Uma rede viva e capilarizada que conecta advogados populares, pesquisadores acadêmicos, clínicas de direitos e organizações nos 9 estados da Amazônia Legal.
          </p>
        </div>

        <!-- Network Interactive Tabs Filter -->
        <div class="flex items-center gap-2 overflow-x-auto pb-4 mb-8 text-nowrap" id="network-filter-tabs">
          <button
            class="network-tab active px-4 py-2 rounded-lg bg-primary text-on-primary font-label-md text-label-md uppercase tracking-wider transition-colors shadow-sm"
            data-target="all" type="button">Todos os Membros</button>
          <button
            class="network-tab px-4 py-2 rounded-lg bg-surface-container-lowest border border-border-subtle text-on-surface-variant font-label-md text-label-md uppercase tracking-wider hover:bg-surface-container-high transition-colors shadow-sm"
            data-target="advocacia" type="button">Advocacia Popular & Coletivos</button>
          <button
            class="network-tab px-4 py-2 rounded-lg bg-surface-container-lowest border border-border-subtle text-on-surface-variant font-label-md text-label-md uppercase tracking-wider hover:bg-surface-container-high transition-colors shadow-sm"
            data-target="pesquisa" type="button">Pesquisa & Clínicas Jurídicas</button>
          <button
            class="network-tab px-4 py-2 rounded-lg bg-surface-container-lowest border border-border-subtle text-on-surface-variant font-label-md text-label-md uppercase tracking-wider hover:bg-surface-container-high transition-colors shadow-sm"
            data-target="sociedade" type="button">Organizações da Sociedade Civil</button>
          <button
            class="network-tab px-4 py-2 rounded-lg bg-surface-container-lowest border border-border-subtle text-on-surface-variant font-label-md text-label-md uppercase tracking-wider hover:bg-surface-container-high transition-colors shadow-sm"
            data-target="diretoria" type="button">Articulação & Conselho</button>
        </div>

        <!-- Grid of Leaders & Nodes (Alimentado dinamicamente pela Categoria "portfolio") -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-gutter mb-space-xl">
          <?php
          $portfolio_query = new WP_Query(array(
              'category_name'  => 'portfolio',
              'posts_per_page' => 12,
              'post_status'    => 'publish',
          ));

          if ($portfolio_query->have_posts()) :
              while ($portfolio_query->have_posts()) : $portfolio_query->the_post();
                  $post_id        = get_the_ID();
                  $cat_filter     = aja_get_portfolio_cat($post_id);
                  $badge          = aja_get_post_badge($post_id, 'Membro da Rede');
                  $subtitle       = aja_get_post_subtitle($post_id, 'Amazônia Legal • AJA');
                  
                  // Cor dinâmica para o badge de acordo com a categoria
                  $badge_color = 'text-secondary';
                  if ($cat_filter === 'diretoria') {
                      $badge_color = 'text-primary';
                  } elseif ($cat_filter === 'pesquisa') {
                      $badge_color = 'text-moss-light';
                  } elseif ($cat_filter === 'sociedade') {
                      $badge_color = 'text-clay-warm';
                  }
                  ?>
                  <div
                    class="network-card bg-surface-container-lowest rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 flex flex-col group border border-border-subtle"
                    data-category="<?php echo esc_attr($cat_filter); ?>">
                    <div class="h-56 bg-surface-container flex flex-col items-center justify-center text-center border-b border-border-subtle select-none overflow-hidden relative">
                      <?php if (has_post_thumbnail()) : ?>
                        <?php the_post_thumbnail('aja-card-thumb', array('class' => 'w-full h-full object-cover transition-transform duration-500 group-hover:scale-105')); ?>
                      <?php else : ?>
                        <div class="p-6 flex flex-col items-center justify-center">
                          <span class="material-symbols-outlined text-4xl text-outline mb-1.5 opacity-60">image</span>
                          <span class="font-label-md text-label-md uppercase tracking-wider text-on-surface-variant font-medium">
                            Imagem a ser colocada
                          </span>
                        </div>
                      <?php endif; ?>
                    </div>
                    <div class="p-6 flex flex-col flex-1 justify-between">
                      <div>
                        <span class="font-label-sm text-label-sm <?php echo esc_attr($badge_color); ?> font-bold uppercase tracking-wider">
                          <?php echo esc_html($badge); ?>
                        </span>
                        <h3 class="font-title-lg text-title-lg text-ink-primary font-bold mt-1">
                          <a href="<?php the_permalink(); ?>" class="hover:text-primary transition-colors">
                            <?php the_title(); ?>
                          </a>
                        </h3>
                        <div class="font-body-sm text-body-sm text-on-surface-variant mt-2 leading-relaxed">
                          <?php the_excerpt(); ?>
                        </div>
                      </div>
                      <div
                        class="flex items-center gap-2 mt-4 pt-4 border-t border-surface-container text-on-surface-variant font-label-sm text-label-sm">
                        <span class="material-symbols-outlined text-[16px] text-primary">location_on</span>
                        <span><?php echo esc_html($subtitle); ?></span>
                      </div>
                    </div>
                  </div>
                  <?php
              endwhile;
              wp_reset_postdata();
          else :
              // Fallback: Exibição dos cards de exemplo caso ainda não haja posts publicados no WordPress
              ?>
              <!-- Card 1 (Fallback) -->
              <div
                class="network-card bg-surface-container-lowest rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 flex flex-col group border border-border-subtle"
                data-category="advocacia">
                <div class="h-56 bg-surface-container flex flex-col items-center justify-center p-6 text-center border-b border-border-subtle select-none">
                  <span class="material-symbols-outlined text-4xl text-outline mb-1.5 opacity-60">image</span>
                  <span class="font-label-md text-label-md uppercase tracking-wider text-on-surface-variant font-medium">
                    Imagem a ser colocada
                  </span>
                </div>
                <div class="p-6 flex flex-col flex-1 justify-between">
                  <div>
                    <span class="font-label-sm text-label-sm text-secondary font-bold uppercase tracking-wider">Advocacia Popular</span>
                    <h3 class="font-title-lg text-title-lg text-ink-primary font-bold mt-1">Nome do Integrante (Exemplo)</h3>
                    <p class="font-body-sm text-body-sm text-on-surface-variant mt-2 leading-relaxed">
                      Isto é um exemplo. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                    </p>
                  </div>
                  <div
                    class="flex items-center gap-2 mt-4 pt-4 border-t border-surface-container text-on-surface-variant font-label-sm text-label-sm">
                    <span class="material-symbols-outlined text-[16px] text-primary">location_on</span> Estado / Região • GT
                  </div>
                </div>
              </div>

              <!-- Card 2 (Fallback) -->
              <div
                class="network-card bg-surface-container-lowest rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 flex flex-col group border border-border-subtle"
                data-category="diretoria">
                <div class="h-56 bg-surface-container flex flex-col items-center justify-center p-6 text-center border-b border-border-subtle select-none">
                  <span class="material-symbols-outlined text-4xl text-outline mb-1.5 opacity-60">image</span>
                  <span class="font-label-md text-label-md uppercase tracking-wider text-on-surface-variant font-medium">
                    Imagem a ser colocada
                  </span>
                </div>
                <div class="p-6 flex flex-col flex-1 justify-between">
                  <div>
                    <span class="font-label-sm text-label-sm text-primary font-bold uppercase tracking-wider">Articulação & Conselho</span>
                    <h3 class="font-title-lg text-title-lg text-ink-primary font-bold mt-1">Nome do Integrante (Exemplo)</h3>
                    <p class="font-body-sm text-body-sm text-on-surface-variant mt-2 leading-relaxed">
                      Isto é um exemplo. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident.
                    </p>
                  </div>
                  <div
                    class="flex items-center gap-2 mt-4 pt-4 border-t border-surface-container text-on-surface-variant font-label-sm text-label-sm">
                    <span class="material-symbols-outlined text-[16px] text-primary">location_on</span> Estado / Região • GT
                  </div>
                </div>
              </div>

              <!-- Card 3 (Fallback) -->
              <div
                class="network-card bg-surface-container-lowest rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 flex flex-col group border border-border-subtle"
                data-category="pesquisa">
                <div class="h-56 bg-surface-container flex flex-col items-center justify-center p-6 text-center border-b border-border-subtle select-none">
                  <span class="material-symbols-outlined text-4xl text-outline mb-1.5 opacity-60">image</span>
                  <span class="font-label-md text-label-md uppercase tracking-wider text-on-surface-variant font-medium">
                    Imagem a ser colocada
                  </span>
                </div>
                <div class="p-6 flex flex-col flex-1 justify-between">
                  <div>
                    <span class="font-label-sm text-label-sm text-moss-light font-bold uppercase tracking-wider">Pesquisa & Clínicas Jurídicas</span>
                    <h3 class="font-title-lg text-title-lg text-ink-primary font-bold mt-1">Nome da Instituição ou Integrante (Exemplo)</h3>
                    <p class="font-body-sm text-body-sm text-on-surface-variant mt-2 leading-relaxed">
                      Isto é um exemplo. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam eaque ipsa quae ab illo inventore veritatis.
                    </p>
                  </div>
                  <div
                    class="flex items-center gap-2 mt-4 pt-4 border-t border-surface-container text-on-surface-variant font-label-sm text-label-sm">
                    <span class="material-symbols-outlined text-[16px] text-primary">location_on</span> Estado / Região • GT
                  </div>
                </div>
              </div>

              <!-- Card 4 (Fallback) -->
              <div
                class="network-card bg-surface-container-lowest rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-all duration-300 flex flex-col group border border-border-subtle"
                data-category="sociedade">
                <div class="h-56 bg-surface-container flex flex-col items-center justify-center p-6 text-center border-b border-border-subtle select-none">
                  <span class="material-symbols-outlined text-4xl text-outline mb-1.5 opacity-60">image</span>
                  <span class="font-label-md text-label-md uppercase tracking-wider text-on-surface-variant font-medium">
                    Imagem a ser colocada
                  </span>
                </div>
                <div class="p-6 flex flex-col flex-1 justify-between">
                  <div>
                    <span class="font-label-sm text-label-sm text-clay-warm font-bold uppercase tracking-wider">Organizações da Sociedade Civil</span>
                    <h3 class="font-title-lg text-title-lg text-ink-primary font-bold mt-1">Nome da Organização ou Integrante (Exemplo)</h3>
                    <p class="font-body-sm text-body-sm text-on-surface-variant mt-2 leading-relaxed">
                      Isto é um exemplo. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.
                    </p>
                  </div>
                  <div
                    class="flex items-center gap-2 mt-4 pt-4 border-t border-surface-container text-on-surface-variant font-label-sm text-label-sm">
                    <span class="material-symbols-outlined text-[16px] text-primary">location_on</span> Estado / Região • GT
                  </div>
                </div>
              </div>
          <?php endif; ?>
        </div>

        <!-- BANCO DE MAPEAMENTO & PORTFÓLIO ESCALÁVEL -->
        <div class="p-8 lg:p-12 rounded-2xl bg-surface-container-low border border-border-subtle flex flex-col lg:flex-row items-center justify-between gap-8 mb-space-xl">
          <div class="flex flex-col gap-3 max-w-2xl">
            <span class="font-label-sm text-label-sm uppercase tracking-widest text-primary font-bold">
              Arquitetura Escalável de Informação
            </span>
            <h3 class="font-headline-md text-headline-md text-ink-primary font-medium">
              Mapeamento Contínuo para Criação do Portfólio da Rede
            </h3>
            <p class="font-body-md text-body-md text-on-surface-variant leading-relaxed">
              A AJA está estruturando o mapeamento colaborativo de iniciativas, litígios estratégicos, notas técnicas e pareceres produzidos pelos seus membros. Uma vitrine pública que dará transparência à incidência jurídica e conectará novas demandas territoriais aos especialistas da rede.
            </p>
          </div>
          <div class="flex flex-col sm:flex-row gap-4 shrink-0 w-full lg:w-auto">
            <a class="px-6 py-3.5 rounded-lg bg-primary hover:bg-moss-light text-on-primary font-label-lg text-label-lg uppercase tracking-wider transition-colors text-center font-bold"
              href="#faca-parte">
              Cadastrar Iniciativa na Rede
            </a>
          </div>
        </div>

        <!-- Territorial Geographic Banner -->
        <div
          class="w-full bg-surface-container-lowest rounded-xl p-8 border border-border-subtle shadow-sm flex flex-col lg:flex-row items-center justify-between gap-8">
          <div class="flex flex-col gap-2 max-w-xl">
            <span class="font-label-sm text-label-sm uppercase tracking-widest text-secondary font-bold">Capilaridade Territorial</span>
            <h3 class="font-headline-md text-headline-md text-ink-primary font-medium">9 Estados da Amazônia Legal + Brasília</h3>
            <p class="font-body-md text-body-md text-on-surface-variant">
              Presença estratégica em Acre, Amapá, Amazonas, Maranhão, Mato Grosso, Pará, Rondônia, Roraima e Tocantins, além de ponto de articulação em Brasília (DF) para acompanhamento direto perante tribunais superiores e órgãos federais.
            </p>
          </div>
          <div class="flex items-center gap-3 flex-wrap justify-end">
            <div class="px-4 py-3 rounded-lg bg-surface-container-low border border-border-subtle flex items-center gap-3">
              <span class="w-3 h-3 rounded-full bg-moss-light"></span>
              <div class="flex flex-col">
                <span class="font-label-md text-label-md font-bold text-on-surface">Polo Norte</span>
                <span class="font-label-sm text-label-sm text-on-surface-variant">Belém & Macapá</span>
              </div>
            </div>
            <div class="px-4 py-3 rounded-lg bg-surface-container-low border border-border-subtle flex items-center gap-3">
              <span class="w-3 h-3 rounded-full bg-clay-warm"></span>
              <div class="flex flex-col">
                <span class="font-label-md text-label-md font-bold text-on-surface">Polo Ocidental</span>
                <span class="font-label-sm text-label-sm text-on-surface-variant">Manaus & Rio Branco</span>
              </div>
            </div>
            <div class="px-4 py-3 rounded-lg bg-surface-container-low border border-border-subtle flex items-center gap-3">
              <span class="w-3 h-3 rounded-full bg-secondary"></span>
              <div class="flex flex-col">
                <span class="font-label-md text-label-md font-bold text-on-surface">Polo Institucional</span>
                <span class="font-label-sm text-label-sm text-on-surface-variant">Brasília (DF)</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- SECTION 5: COOPERAÇÃO E PARCEIROS ESTRATÉGICOS -->
    <section class="w-full py-16 bg-surface border-t border-border-subtle" id="parceiros">
      <a id="apoiadores" class="sr-only"></a>
      <div class="max-w-[1440px] mx-auto px-margin-mobile lg:px-margin">
        <div class="flex flex-col items-center text-center mb-10">
          <span class="font-label-sm text-label-sm uppercase tracking-widest text-primary font-bold">Articulação Coletiva</span>
          <h3 class="font-headline-sm text-headline-sm text-ink-primary font-medium mt-1">Parceiros Estratégicos e Redes Conectadas</h3>
        </div>
        <!-- Partners Grid -->
        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-6 items-stretch py-2">
          <!-- 1. Amazon Investor Coalition -->
          <a href="https://amazoninvestor.org/" target="_blank" rel="noopener noreferrer"
            class="relative px-5 py-6 rounded-2xl bg-surface-container-lowest shadow-sm border border-border-subtle flex items-center justify-center text-center hover:shadow-lg hover:border-primary/50 transition-all duration-300 group h-32 lg:h-36"
            title="Amazon Investor Coalition">
            <img alt="Amazon Investor Coalition"
              class="max-h-16 lg:max-h-20 w-auto max-w-[90%] object-contain opacity-95 group-hover:opacity-100 transition-all duration-300 group-hover:scale-105"
              src="<?php echo esc_url(aja_asset('parceiros/amazon investor coalition.png')); ?>" />
            <span class="absolute -bottom-3.5 left-1/2 -translate-x-1/2 px-3 py-1 rounded-md bg-earth-dark text-white text-[12px] font-label-sm font-medium whitespace-nowrap shadow-xl opacity-0 group-hover:opacity-100 group-hover:-translate-y-1 transition-all duration-200 pointer-events-none z-30">
              Amazon Investor Coalition
            </span>
          </a>

          <!-- 2. Center for Climate Crime Analysis -->
          <a href="https://climatecrimeanalysis.org/" target="_blank" rel="noopener noreferrer"
            class="relative px-5 py-6 rounded-2xl bg-surface-container-lowest shadow-sm border border-border-subtle flex items-center justify-center text-center hover:shadow-lg hover:border-primary/50 transition-all duration-300 group h-32 lg:h-36"
            title="Center for Climate Crime Analysis">
            <img alt="Center for Climate Crime Analysis"
              class="max-h-16 lg:max-h-20 w-auto max-w-[90%] object-contain opacity-95 group-hover:opacity-100 transition-all duration-300 group-hover:scale-105"
              src="<?php echo esc_url(aja_asset('parceiros/center for climate crime analysis.png')); ?>" />
            <span class="absolute -bottom-3.5 left-1/2 -translate-x-1/2 px-3 py-1 rounded-md bg-earth-dark text-white text-[12px] font-label-sm font-medium whitespace-nowrap shadow-xl opacity-0 group-hover:opacity-100 group-hover:-translate-y-1 transition-all duration-200 pointer-events-none z-30">
              CCCA
            </span>
          </a>

          <!-- 3. LACLIMA -->
          <a href="https://www.laclima.org/" target="_blank" rel="noopener noreferrer"
            class="relative px-5 py-6 rounded-2xl bg-surface-container-lowest shadow-sm border border-border-subtle flex items-center justify-center text-center hover:shadow-lg hover:border-primary/50 transition-all duration-300 group h-32 lg:h-36"
            title="LACLIMA">
            <img alt="LACLIMA"
              class="max-h-16 lg:max-h-20 w-auto max-w-[90%] object-contain opacity-95 group-hover:opacity-100 transition-all duration-300 group-hover:scale-105"
              src="<?php echo esc_url(aja_asset('parceiros/lacilma.png')); ?>" />
            <span class="absolute -bottom-3.5 left-1/2 -translate-x-1/2 px-3 py-1 rounded-md bg-earth-dark text-white text-[12px] font-label-sm font-medium whitespace-nowrap shadow-xl opacity-0 group-hover:opacity-100 group-hover:-translate-y-1 transition-all duration-200 pointer-events-none z-30">
              LACLIMA
            </span>
          </a>

          <!-- 4. Maparajuba Advocacia Popular -->
          <a href="https://maparajuba.org/" target="_blank" rel="noopener noreferrer"
            class="relative px-5 py-6 rounded-2xl bg-surface-container-lowest shadow-sm border border-border-subtle flex items-center justify-center text-center hover:shadow-lg hover:border-primary/50 transition-all duration-300 group h-32 lg:h-36"
            title="Maparajuba Advocacia Popular">
            <img alt="Maparajuba Advocacia Popular"
              class="max-h-14 lg:max-h-18 w-auto max-w-[94%] object-contain opacity-95 group-hover:opacity-100 transition-all duration-300 group-hover:scale-105"
              src="<?php echo esc_url(aja_asset('parceiros/maparajuba.png')); ?>" />
            <span class="absolute -bottom-3.5 left-1/2 -translate-x-1/2 px-3 py-1 rounded-md bg-earth-dark text-white text-[12px] font-label-sm font-medium whitespace-nowrap shadow-xl opacity-0 group-hover:opacity-100 group-hover:-translate-y-1 transition-all duration-200 pointer-events-none z-30">
              Maparajuba Advocacia Popular
            </span>
          </a>

          <!-- 5. Rede Amazonidas pelo Clima -->
          <a href="https://www.rac-br.org/" target="_blank" rel="noopener noreferrer"
            class="relative px-5 py-6 rounded-2xl bg-surface-container-lowest shadow-sm border border-border-subtle flex items-center justify-center text-center hover:shadow-lg hover:border-primary/50 transition-all duration-300 group h-32 lg:h-36"
            title="Rede Amazonidas pelo Clima">
            <img alt="Rede Amazonidas pelo Clima"
              class="max-h-16 lg:max-h-20 w-auto max-w-[90%] object-contain opacity-95 group-hover:opacity-100 transition-all duration-300 group-hover:scale-105"
              src="<?php echo esc_url(aja_asset('parceiros/rede anazonidas pelo clima.png')); ?>" />
            <span class="absolute -bottom-3.5 left-1/2 -translate-x-1/2 px-3 py-1 rounded-md bg-earth-dark text-white text-[12px] font-label-sm font-medium whitespace-nowrap shadow-xl opacity-0 group-hover:opacity-100 group-hover:-translate-y-1 transition-all duration-200 pointer-events-none z-30">
              Rede Amazonidas pelo Clima
            </span>
          </a>

          <!-- 6. Rede Liberdade -->
          <a href="https://redeliberdade.org.br/" target="_blank" rel="noopener noreferrer"
            class="relative px-5 py-6 rounded-2xl bg-surface-container-lowest shadow-sm border border-border-subtle flex items-center justify-center text-center hover:shadow-lg hover:border-primary/50 transition-all duration-300 group h-32 lg:h-36"
            title="Rede Liberdade">
            <img alt="Rede Liberdade"
              class="max-h-14 lg:max-h-18 w-auto max-w-[94%] object-contain opacity-95 group-hover:opacity-100 transition-all duration-300 group-hover:scale-105"
              src="<?php echo esc_url(aja_asset('parceiros/rede liberdade.png')); ?>" />
            <span class="absolute -bottom-3.5 left-1/2 -translate-x-1/2 px-3 py-1 rounded-md bg-earth-dark text-white text-[12px] font-label-sm font-medium whitespace-nowrap shadow-xl opacity-0 group-hover:opacity-100 group-hover:-translate-y-1 transition-all duration-200 pointer-events-none z-30">
              Rede Liberdade
            </span>
          </a>
        </div>
      </div>
    </section>

    <!-- SECTION 6: SEJA MEMBRO / FAÇA PARTE -->
    <section class="w-full py-space-xl bg-surface-container border-t border-border-subtle" id="faca-parte">
      <div class="max-w-[1440px] mx-auto px-margin-mobile lg:px-margin">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-gutter items-center">
          <!-- Guidelines Column -->
          <div class="lg:col-span-6 flex flex-col gap-6">
            <div class="flex items-center gap-3">
              <span class="w-8 h-[2px] bg-secondary"></span>
              <span class="font-label-md text-label-md text-secondary uppercase tracking-widest font-bold">
                Faça Parte • Porta de entrada para integrar os Grupos Temáticos
              </span>
            </div>
            <h2
              class="font-headline-lg text-headline-lg-mobile lg:text-headline-lg text-ink-primary font-medium leading-tight">
              Faça Parte da Aliança Jurídica pela Amazônia
            </h2>
            <div class="flex flex-col gap-4 font-body-lg text-body-md text-on-surface-variant leading-relaxed">
              <p>
                A Aliança Jurídica pela Amazônia é um espaço aberto à colaboração de advogados(as), pesquisadores(as), organizações da sociedade civil, escritórios de advocacia, coletivos jurídicos e clínicas de direitos que compartilham do nosso propósito e dos princípios que orientam nossa atuação.
              </p>
              <p>
                Se você acredita em uma Amazônia com justiça, integridade territorial e protagonismo dos povos, queremos caminhar junto com você.
              </p>
              <p>
                Preencha o formulário de adesão e venha contribuir com esta rede.
              </p>
            </div>

            <!-- Steps for Joining -->
            <div class="flex flex-col gap-4 mt-2">
              <div class="flex items-start gap-4">
                <div
                  class="w-8 h-8 rounded-full bg-primary-container text-on-primary flex items-center justify-center shrink-0 mt-1 font-bold text-label-sm">
                  1</div>
                <div>
                  <h4 class="font-title-md text-title-md font-bold text-ink-primary">Preenchimento do Formulário</h4>
                  <p class="font-body-sm text-body-sm text-on-surface-variant">Apresente sua trajetória, organização ou coletivo de atuação na ou pela Amazônia.</p>
                </div>
              </div>
              <div class="flex items-start gap-4">
                <div
                  class="w-8 h-8 rounded-full bg-primary-container text-on-primary flex items-center justify-center shrink-0 mt-1 font-bold text-label-sm">
                  2</div>
                <div>
                  <h4 class="font-title-md text-title-md font-bold text-ink-primary">Alinhamento aos Princípios</h4>
                  <p class="font-body-sm text-body-sm text-on-surface-variant">Adesão expressa aos 8 princípios fundamentais e salvaguardas dos povos e comunidades tradicionais.</p>
                </div>
              </div>
              <div class="flex items-start gap-4">
                <div
                  class="w-8 h-8 rounded-full bg-primary-container text-on-primary flex items-center justify-center shrink-0 mt-1 font-bold text-label-sm">
                  3</div>
                <div>
                  <h4 class="font-title-md text-title-md font-bold text-ink-primary">Integração aos GTs e Plenárias</h4>
                  <p class="font-body-sm text-body-sm text-on-surface-variant">Participação ativa nos Grupos Temáticos técnicos e nas decisões estratégicas da rede.</p>
                </div>
              </div>
            </div>

            <div class="p-4 bg-surface-container-lowest border border-border-subtle rounded-xl flex items-center gap-3 text-body-sm text-on-surface shadow-sm">
              <span class="material-symbols-outlined text-[22px] text-primary shrink-0">mail</span>
              <span>Em caso de dúvidas sobre adesão, entre em contato pelo e-mail: <a href="mailto:info@ajamazonia.org" class="font-semibold text-primary hover:underline">info@ajamazonia.org</a></span>
            </div>
          </div>

          <!-- Conversion Action Box -->
          <div class="lg:col-span-6">
            <div class="bg-surface-container-lowest p-8 lg:p-12 rounded-2xl shadow-sm border border-border-subtle flex flex-col gap-6">
              <div class="flex items-center justify-between">
                <span class="px-3 py-1 rounded bg-tertiary-fixed text-on-tertiary-fixed font-label-sm text-label-sm font-bold uppercase tracking-wider">
                  Adesão Aberta
                </span>
                <span class="font-label-sm text-label-sm text-outline">Processo Contínuo</span>
              </div>

              <div class="flex flex-col gap-3">
                <h3 class="font-headline-sm text-headline-sm text-ink-primary font-bold">
                  Formulário Oficial de Adesão à AJA
                </h3>
                <p class="font-body-md text-body-md text-on-surface-variant leading-relaxed">
                  Clique no botão abaixo para acessar o formulário oficial de adesão e cadastrar seus dados e área de interesse nos Grupos Temáticos.
                </p>
              </div>

              <div class="p-6 bg-surface-container-low rounded-xl flex flex-col gap-3 border border-border-subtle">
                <div class="flex items-center gap-2 font-label-md text-label-md text-ink-primary font-bold">
                  <span class="material-symbols-outlined text-[20px] text-primary">verified</span>
                  Quem pode se associar:
                </div>
                <ul class="font-body-sm text-body-sm text-on-surface-variant space-y-1.5 list-disc pl-5">
                  <li>Advogados e advogadas atuantes na defesa socioambiental</li>
                  <li>Pesquisadores, professores e membros de clínicas de direito</li>
                  <li>Organizações da sociedade civil e ONGs</li>
                  <li>Coletivos jurídicos de base e assessorias populares</li>
                  <li>Escritórios de advocacia comprometidos com o fortalecimento do Estado de Direito</li>
                </ul>
              </div>

              <a class="w-full py-4 px-6 rounded-lg bg-primary hover:bg-moss-light text-on-primary font-label-lg text-label-lg uppercase tracking-wider transition-all duration-200 flex items-center justify-center gap-2 shadow-md hover:shadow-lg font-bold text-center"
                href="https://docs.google.com/forms/d/e/1FAIpQLSeAuZ5N3FxsVX0HrQ9dhrCqyEPuAmWgR-IOEXm1m35Z_Nxjhg/viewform?usp=send_form"
                target="_blank" rel="noopener noreferrer">
                <span>Preencher Formulário de Adesão</span>
                <span class="material-symbols-outlined text-[20px]">open_in_new</span>
              </a>

              <p class="font-body-sm text-body-sm text-outline text-center">
                Formulário seguro no Google Forms. Tempo estimado: 5 minutos.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- ========================================================================= -->
    <!-- SECTION 7: EDITAIS & SUBMISSÕES (CATEGORIA 2: "editais")                  -->
    <!-- ========================================================================= -->
    <section class="w-full py-space-xl bg-surface border-t border-border-subtle" id="editais">
      <div class="max-w-[1440px] mx-auto px-margin-mobile lg:px-margin">
        <!-- Section Header -->
        <div class="flex items-center gap-3 mb-2">
          <span class="w-8 h-[2px] bg-secondary"></span>
          <span class="font-label-md text-label-md text-secondary uppercase tracking-widest font-bold">Submissões & Oportunidades</span>
        </div>
        <div class="flex flex-col md:flex-row md:items-end justify-between mb-space-lg gap-4">
          <div>
            <h2 class="font-headline-lg text-headline-lg-mobile lg:text-headline-lg text-ink-primary font-medium">
              Editais e Chamadas para Submissão
            </h2>
          </div>
          <p class="font-body-sm text-body-sm text-on-surface-variant max-w-sm">
            Mecanismos públicos e transparentes para mobilização de inteligência jurídica, artigos inéditos e pareceres na Amazônia.
          </p>
        </div>

        <?php
        $editais_query = new WP_Query(array(
            'category_name'  => 'editais',
            'posts_per_page' => 10,
            'post_status'    => 'publish',
        ));

        if ($editais_query->have_posts()) :
            // Procura o post com meta featured ou usa o primeiro post
            $featured_post = null;
            $other_posts   = array();

            while ($editais_query->have_posts()) {
                $editais_query->the_post();
                $is_featured = get_post_meta(get_the_ID(), '_aja_featured_edital', true);
                if ($is_featured === '1' && !$featured_post) {
                    $featured_post = get_post();
                } else {
                    $other_posts[] = get_post();
                }
            }
            wp_reset_postdata();

            // Se nenhum tiver a flag 'featured', usa o primeiro
            if (!$featured_post && !empty($other_posts)) {
                $featured_post = array_shift($other_posts);
            }

            if ($featured_post) :
                $feat_id     = $featured_post->ID;
                $feat_badge  = aja_get_post_badge($feat_id, 'Chamada Pública Aberta');
                $feat_sub    = aja_get_post_subtitle($feat_id, 'Destinada aos Membros da AJA');
                $feat_link   = aja_get_post_action_link($feat_id);
                $feat_label  = aja_get_post_action_label($feat_id, 'Acessar Edital & Submissão');
                $feat_thumb  = has_post_thumbnail($feat_id) 
                               ? get_the_post_thumbnail_url($feat_id, 'aja-banner') 
                               : aja_asset('fotos/corredeira-floresta-pedras.jpg');
                ?>
                <!-- Featured Callout Card Dinâmico -->
                <div
                  class="w-full relative overflow-hidden text-surface-container-lowest rounded-2xl p-8 lg:p-12 mb-8 shadow-sm flex flex-col lg:flex-row justify-between items-start lg:items-center gap-8 group">
                  <div class="absolute inset-0 z-0">
                    <img alt="<?php echo esc_attr($featured_post->post_title); ?>"
                      class="w-full h-full object-cover opacity-25 mix-blend-luminosity scale-105 transition-transform duration-700 group-hover:scale-110"
                      src="<?php echo esc_url($feat_thumb); ?>" />
                    <div class="absolute inset-0 bg-gradient-to-r from-primary via-primary/95 to-primary-container/90"></div>
                  </div>
                  <div class="relative z-10 flex flex-col gap-4 max-w-3xl">
                    <div class="flex items-center gap-3">
                      <span
                        class="px-3 py-1 rounded bg-tertiary-fixed text-on-tertiary-fixed font-label-sm text-label-sm uppercase tracking-wider font-bold">
                        <?php echo esc_html($feat_badge); ?>
                      </span>
                      <span class="font-label-sm text-label-sm text-primary-fixed-dim">
                        <?php echo esc_html($feat_sub); ?>
                      </span>
                    </div>
                    <h3 class="font-headline-md text-headline-md font-bold leading-tight">
                      <?php echo esc_html($featured_post->post_title); ?>
                    </h3>
                    <div class="font-body-md text-body-md text-surface-container leading-relaxed">
                      <?php echo apply_filters('the_excerpt', $featured_post->post_excerpt ?: wp_trim_words($featured_post->post_content, 40)); ?>
                    </div>
                    <div class="flex items-center gap-2 pt-1 text-primary-fixed text-body-sm">
                      <span class="material-symbols-outlined text-[18px]">info</span>
                      <span>Dúvidas sobre a chamada: <strong>info@ajamazonia.org</strong></span>
                    </div>
                  </div>
                  <div class="relative z-10 flex flex-col sm:flex-row items-center gap-4 shrink-0 w-full lg:w-auto">
                    <a class="w-full sm:w-auto px-6 py-3.5 rounded-lg bg-surface-container-lowest text-primary hover:bg-surface-container font-label-lg text-label-lg uppercase tracking-wider transition-colors font-bold text-center shadow-md flex items-center justify-center gap-2"
                      href="<?php echo esc_url($feat_link); ?>">
                      <span><?php echo esc_html($feat_label); ?></span>
                      <span class="material-symbols-outlined text-[18px]">download</span>
                    </a>
                  </div>
                </div>
            <?php endif; ?>

            <!-- Secondary Continuous Opportunities Dinâmicos -->
            <?php if (!empty($other_posts)) : ?>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-gutter">
                  <?php foreach (array_slice($other_posts, 0, 4) as $index => $op_post) : 
                      $op_id    = $op_post->ID;
                      $op_badge = aja_get_post_badge($op_id, 'Fluxo Contínuo');
                      $op_sub   = aja_get_post_subtitle($op_id, 'Credenciamento de Membros');
                      $op_link  = aja_get_post_action_link($op_id);
                      $op_label = aja_get_post_action_label($op_id, 'Manifestar Interesse');
                      $badge_class = ($index % 2 === 0) ? 'bg-secondary-fixed text-on-secondary-fixed' : 'bg-primary-fixed text-on-primary-fixed';
                      ?>
                      <div class="p-8 rounded-xl bg-surface-container-low shadow-sm flex flex-col justify-between border border-border-subtle">
                        <div>
                          <div class="flex items-center justify-between mb-4">
                            <span
                              class="px-2.5 py-1 rounded <?php echo esc_attr($badge_class); ?> font-label-sm text-label-sm font-semibold uppercase tracking-wider">
                              <?php echo esc_html($op_badge); ?>
                            </span>
                            <span class="font-label-sm text-label-sm text-on-surface-variant">Fluxo Contínuo</span>
                          </div>
                          <h4 class="font-title-lg text-title-lg text-ink-primary font-bold mb-2">
                            <a href="<?php echo esc_url(get_permalink($op_id)); ?>" class="hover:text-primary transition-colors">
                              <?php echo esc_html($op_post->post_title); ?>
                            </a>
                          </h4>
                          <div class="font-body-md text-body-md text-on-surface-variant leading-relaxed">
                            <?php echo apply_filters('the_excerpt', $op_post->post_excerpt ?: wp_trim_words($op_post->post_content, 30)); ?>
                          </div>
                        </div>
                        <div class="mt-6 pt-4 border-t border-surface-container flex items-center justify-between">
                          <span class="font-label-sm text-label-sm text-clay-warm font-semibold"><?php echo esc_html($op_sub); ?></span>
                          <a class="font-label-md text-label-md text-primary font-bold hover:underline inline-flex items-center gap-1"
                            href="<?php echo esc_url($op_link); ?>">
                            <?php echo esc_html($op_label); ?> <span class="material-symbols-outlined text-[16px]">chevron_right</span>
                          </a>
                        </div>
                      </div>
                  <?php endforeach; ?>
                </div>
            <?php endif; ?>

        <?php else : ?>
            <!-- Fallback: Editais originais de modelo caso ainda não existam posts cadastrados -->
            <!-- Featured Callout Card: CHAMADA PARA SUBMISSÃO DE ARTIGOS -->
            <div
              class="w-full relative overflow-hidden text-surface-container-lowest rounded-2xl p-8 lg:p-12 mb-8 shadow-sm flex flex-col lg:flex-row justify-between items-start lg:items-center gap-8 group">
              <div class="absolute inset-0 z-0">
                <img alt="Floresta e corredeiras amazônicas"
                  class="w-full h-full object-cover opacity-25 mix-blend-luminosity scale-105 transition-transform duration-700 group-hover:scale-110"
                  src="<?php echo esc_url(aja_asset('fotos/corredeira-floresta-pedras.jpg')); ?>" />
                <div class="absolute inset-0 bg-gradient-to-r from-primary via-primary/95 to-primary-container/90"></div>
              </div>
              <div class="relative z-10 flex flex-col gap-4 max-w-3xl">
                <div class="flex items-center gap-3">
                  <span
                    class="px-3 py-1 rounded bg-tertiary-fixed text-on-tertiary-fixed font-label-sm text-label-sm uppercase tracking-wider font-bold">
                    Chamada Pública Aberta
                  </span>
                  <span class="font-label-sm text-label-sm text-primary-fixed-dim">Destinada aos Membros da AJA</span>
                </div>
                <h3 class="font-headline-md text-headline-md font-bold leading-tight">
                  Chamada para Submissão de Artigos de Opinião Jurídicos
                </h3>
                <p class="font-body-md text-body-md text-surface-container leading-relaxed">
                  A Aliança Jurídica pela Amazônia (AJA) torna pública a chamada para submissão de artigos de opinião jurídicos voltados ao fortalecimento do debate sobre justiça, democracia socioambiental e Estado de Direito na Amazônia.
                </p>
                <p class="font-body-sm text-body-sm text-surface-container-high leading-relaxed">
                  A iniciativa é destinada aos membros da AJA e busca reunir contribuições inéditas sobre temas jurídicos contemporâneos relacionados à Amazônia, aos direitos humanos e à proteção socioambiental. O edital e formulário completo contém informações sobre critérios, eixos temáticos, prazos e orientações para submissão.
                </p>
                <div class="flex items-center gap-2 pt-1 text-primary-fixed text-body-sm">
                  <span class="material-symbols-outlined text-[18px]">info</span>
                  <span>Dúvidas sobre a chamada: <strong>info@ajamazonia.org</strong></span>
                </div>
              </div>
              <div class="relative z-10 flex flex-col sm:flex-row items-center gap-4 shrink-0 w-full lg:w-auto">
                <a class="w-full sm:w-auto px-6 py-3.5 rounded-lg bg-surface-container-lowest text-primary hover:bg-surface-container font-label-lg text-label-lg uppercase tracking-wider transition-colors font-bold text-center shadow-md flex items-center justify-center gap-2"
                  href="mailto:info@ajamazonia.org?subject=Submissao%20de%20Artigo%20AJA">
                  <span>Acessar Edital & Submissão</span>
                  <span class="material-symbols-outlined text-[18px]">download</span>
                </a>
              </div>
            </div>

            <!-- Secondary Continuous Opportunities -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-gutter">
              <div class="p-8 rounded-xl bg-surface-container-low shadow-sm flex flex-col justify-between border border-border-subtle">
                <div>
                  <div class="flex items-center justify-between mb-4">
                    <span
                      class="px-2.5 py-1 rounded bg-secondary-fixed text-on-secondary-fixed font-label-sm text-label-sm font-semibold uppercase tracking-wider">
                      Perícia & Cartografia
                    </span>
                    <span class="font-label-sm text-label-sm text-on-surface-variant">Fluxo Contínuo</span>
                  </div>
                  <h4 class="font-title-lg text-title-lg text-ink-primary font-bold mb-2">
                    Chamada Contínua: Banco de Especialistas em Perícia Ambiental
                  </h4>
                  <p class="font-body-md text-body-md text-on-surface-variant leading-relaxed">
                    Credenciamento de peritos independentes, cartógrafos sociais e antropólogos para auxílio pro bono em laudos técnicos de demarcação territorial, licenciamento e combate a crimes ambientais.
                  </p>
                </div>
                <div class="mt-6 pt-4 border-t border-surface-container flex items-center justify-between">
                  <span class="font-label-sm text-label-sm text-clay-warm font-semibold">Credenciamento de Membros</span>
                  <a class="font-label-md text-label-md text-primary font-bold hover:underline inline-flex items-center gap-1"
                    href="mailto:info@ajamazonia.org?subject=Credenciamento%20Banco%20de%20Especialistas">
                    Manifestar Interesse <span class="material-symbols-outlined text-[16px]">chevron_right</span>
                  </a>
                </div>
              </div>

              <div class="p-8 rounded-xl bg-surface-container-low shadow-sm flex flex-col justify-between border border-border-subtle">
                <div>
                  <div class="flex items-center justify-between mb-4">
                    <span
                      class="px-2.5 py-1 rounded bg-primary-fixed text-on-primary-fixed font-label-sm text-label-sm font-semibold uppercase tracking-wider">
                      Amicus Curiae
                    </span>
                    <span class="font-label-sm text-label-sm text-on-surface-variant">Fluxo Contínuo</span>
                  </div>
                  <h4 class="font-title-lg text-title-lg text-ink-primary font-bold mb-2">
                    Proposição de Teses e Memoriais para Tribunais Superiores
                  </h4>
                  <p class="font-body-md text-body-md text-on-surface-variant leading-relaxed">
                    Envio de memoriais e notas técnicas fundamentadas para validação e submissão conjunta sob a chancela da AJA perante o Supremo Tribunal Federal (STF) e Superior Tribunal de Justiça (STJ).
                  </p>
                </div>
                <div class="mt-6 pt-4 border-t border-surface-container flex items-center justify-between">
                  <span class="font-label-sm text-label-sm text-clay-warm font-semibold">Avaliação pelo GT 02</span>
                  <a class="font-label-md text-label-md text-primary font-bold hover:underline inline-flex items-center gap-1"
                    href="mailto:info@ajamazonia.org?subject=Proposicao%20Amicus%20Curiae%20AJA">
                    Submeter Proposição <span class="material-symbols-outlined text-[16px]">chevron_right</span>
                  </a>
                </div>
              </div>
            </div>
        <?php endif; ?>
      </div>
    </section>

    <!-- ========================================================================= -->
    <!-- SECTION 8: CONHECIMENTO & PRODUÇÃO INTELECTUAL (CATEGORIA 3: "publicacoes")-->
    <!-- ========================================================================= -->
    <section class="w-full py-space-xl bg-surface-container border-t border-border-subtle" id="conhecimento">
      <div class="max-w-[1440px] mx-auto px-margin-mobile lg:px-margin">
        <!-- Section Header -->
        <div class="flex items-center gap-3 mb-2">
          <span class="w-8 h-[2px] bg-secondary"></span>
          <span class="font-label-md text-label-md text-secondary uppercase tracking-widest font-bold">Vitrine de Conhecimento</span>
        </div>
        <div class="flex flex-col md:flex-row md:items-end justify-between mb-space-lg gap-4">
          <div>
            <h2 class="font-headline-lg text-headline-lg-mobile lg:text-headline-lg text-ink-primary font-medium">
              Publicações, Artigos e Notas Técnicas
            </h2>
          </div>
          <div class="flex items-center gap-3">
            <a href="#editais"
              class="px-4 py-2 rounded-lg bg-surface-container-lowest text-primary font-label-md text-label-md uppercase tracking-wider shadow-sm hover:bg-surface-container transition-colors inline-flex items-center gap-1.5">
              <span class="material-symbols-outlined text-[18px]">add_circle</span>
              Publicar Artigo
            </a>
          </div>
        </div>

        <!-- Publications Grid (Alimentado dinamicamente pela Categoria "publicacoes") -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-gutter">
          <?php
          $publicacoes_query = new WP_Query(array(
              'category_name'  => 'publicacoes,publicações',
              'posts_per_page' => 6,
              'post_status'    => 'publish',
          ));

          if ($publicacoes_query->have_posts()) :
              $pub_index = 0;
              while ($publicacoes_query->have_posts()) : $publicacoes_query->the_post();
                  $pub_id     = get_the_ID();
                  $pub_badge  = aja_get_post_badge($pub_id, 'Nota Técnica');
                  $pub_sub    = aja_get_post_subtitle($pub_id, 'GT 03 • Finanças Sustentáveis');
                  $pub_link   = aja_get_post_action_link($pub_id);
                  $pub_label  = aja_get_post_action_label($pub_id, 'Ver Parecer');

                  // Variação de cores dos selos de acordo com o index
                  $badge_style = 'text-primary';
                  if ($pub_index % 3 === 1) {
                      $badge_style = 'text-secondary';
                  } elseif ($pub_index % 3 === 2) {
                      $badge_style = 'text-earth-dark';
                  }
                  $pub_index++;
                  ?>
                  <div
                    class="bg-surface-container-lowest rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow flex flex-col border border-border-subtle group">
                    <div class="h-48 overflow-hidden relative">
                      <?php if (has_post_thumbnail()) : ?>
                        <?php the_post_thumbnail('aja-card-thumb', array('class' => 'w-full h-full object-cover group-hover:scale-105 transition-transform duration-500')); ?>
                      <?php else : ?>
                        <img alt="<?php the_title_attribute(); ?>"
                          class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                          src="<?php echo esc_url(aja_asset('fotos/pexels-diego-agudelo-257100874-12577779.jpg')); ?>" />
                      <?php endif; ?>
                      <span
                        class="absolute top-3 left-3 px-2 py-0.5 rounded bg-surface-container-lowest/90 backdrop-blur <?php echo esc_attr($badge_style); ?> font-label-sm text-label-sm font-semibold uppercase tracking-wider">
                        <?php echo esc_html($pub_badge); ?>
                      </span>
                    </div>
                    <div class="p-6 flex flex-col flex-1 justify-between">
                      <div>
                        <span class="font-label-sm text-label-sm text-on-surface-variant">
                          <?php echo esc_html($pub_sub); ?>
                        </span>
                        <h3 class="font-title-lg text-title-lg text-ink-primary font-bold mt-2">
                          <a href="<?php echo esc_url($pub_link); ?>" class="hover:text-primary transition-colors">
                            <?php the_title(); ?>
                          </a>
                        </h3>
                        <div class="font-body-sm text-body-sm text-on-surface-variant mt-2 leading-relaxed">
                          <?php the_excerpt(); ?>
                        </div>
                      </div>
                      <div class="mt-6 pt-4 border-t border-surface-container flex items-center justify-between">
                        <span class="font-label-sm text-label-sm text-clay-warm font-semibold">Produção da Rede</span>
                        <a class="font-label-sm text-label-sm text-primary font-bold hover:underline inline-flex items-center gap-1"
                          href="<?php echo esc_url($pub_link); ?>">
                          <?php echo esc_html($pub_label); ?> <span class="material-symbols-outlined text-[16px]">chevron_right</span>
                        </a>
                      </div>
                    </div>
                  </div>
                  <?php
              endwhile;
              wp_reset_postdata();
          else :
              // Fallback: 3 Publicações originais de demonstração
              ?>
              <!-- Pub 1 (Fallback) -->
              <div
                class="bg-surface-container-lowest rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow flex flex-col border border-border-subtle">
                <div class="h-48 overflow-hidden relative">
                  <img alt="Rio Negro e floresta amazônica"
                    class="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                    src="<?php echo esc_url(aja_asset('fotos/pexels-diego-agudelo-257100874-12577779.jpg')); ?>" />
                  <span
                    class="absolute top-3 left-3 px-2 py-0.5 rounded bg-surface-container-lowest/90 backdrop-blur text-primary font-label-sm text-label-sm font-semibold uppercase tracking-wider">
                    Nota Técnica
                  </span>
                </div>
                <div class="p-6 flex flex-col flex-1 justify-between">
                  <div>
                    <span class="font-label-sm text-label-sm text-on-surface-variant">GT 03 • Finanças Sustentáveis</span>
                    <h3 class="font-title-lg text-title-lg text-ink-primary font-bold mt-2">
                      Salvaguardas Mandatórias para Créditos de Carbono Jurisdicionais na Amazônia
                    </h3>
                    <p class="font-body-sm text-body-sm text-on-surface-variant mt-2 leading-relaxed">
                      Análise comparativa das regulações estaduais frente aos padrões internacionais de integridade e direitos territoriais dos povos tradicionais.
                    </p>
                  </div>
                  <div class="mt-6 pt-4 border-t border-surface-container flex items-center justify-between">
                    <span class="font-label-sm text-label-sm text-clay-warm font-semibold">Produção da Rede</span>
                    <a class="font-label-sm text-label-sm text-primary font-bold hover:underline inline-flex items-center gap-1"
                      href="#">
                      Ver Parecer <span class="material-symbols-outlined text-[16px]">chevron_right</span>
                    </a>
                  </div>
                </div>
              </div>

              <!-- Pub 2 (Fallback) -->
              <div
                class="bg-surface-container-lowest rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow flex flex-col border border-border-subtle">
                <div class="h-48 overflow-hidden relative">
                  <img alt="Floresta primária e raios solares"
                    class="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                    src="<?php echo esc_url(aja_asset('fotos/pexels-eduardo-amorim-2155150050-33570703.jpg')); ?>" />
                  <span
                    class="absolute top-3 left-3 px-2 py-0.5 rounded bg-surface-container-lowest/90 backdrop-blur text-secondary font-label-sm text-label-sm font-semibold uppercase tracking-wider">
                    Dossiê Jurídico
                  </span>
                </div>
                <div class="p-6 flex flex-col flex-1 justify-between">
                  <div>
                    <span class="font-label-sm text-label-sm text-on-surface-variant">GT 02 • Litigância Estratégica</span>
                    <h3 class="font-title-lg text-title-lg text-ink-primary font-bold mt-2">
                      A Litigância Climática Brasileira nos Tribunais Superiores: Mapeamento de Julgados
                    </h3>
                    <p class="font-body-sm text-body-sm text-on-surface-variant mt-2 leading-relaxed">
                      Compilado de acórdãos com teses fixadas sobre prescrição de ilícitos ambientais, recomposição de áreas e tutela preventiva socioecológica.
                    </p>
                  </div>
                  <div class="mt-6 pt-4 border-t border-surface-container flex items-center justify-between">
                    <span class="font-label-sm text-label-sm text-clay-warm font-semibold">Produção da Rede</span>
                    <a class="font-label-sm text-label-sm text-primary font-bold hover:underline inline-flex items-center gap-1"
                      href="#">
                      Ver Dossiê <span class="material-symbols-outlined text-[16px]">chevron_right</span>
                    </a>
                  </div>
                </div>
              </div>

              <!-- Pub 3 (Fallback) -->
              <div
                class="bg-surface-container-lowest rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow flex flex-col border border-border-subtle">
                <div class="h-48 overflow-hidden relative">
                  <img alt="Canal fluvial natural emoldurado por copas densas de árvores nativas"
                    class="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                    src="<?php echo esc_url(aja_asset('fotos/pexels-eliezer-nunes-300283905-26146919.jpg')); ?>" />
                  <span
                    class="absolute top-3 left-3 px-2 py-0.5 rounded bg-surface-container-lowest/90 backdrop-blur text-earth-dark font-label-sm text-label-sm font-semibold uppercase tracking-wider">
                    Guia Prático
                  </span>
                </div>
                <div class="p-6 flex flex-col flex-1 justify-between">
                  <div>
                    <span class="font-label-sm text-label-sm text-on-surface-variant">GT 01 • Territórios & PIQCTs</span>
                    <h3 class="font-title-lg text-title-lg text-ink-primary font-bold mt-2">
                      Protocolos Autônomos de Consulta: Manual de Redação e Validação Jurídica
                    </h3>
                    <p class="font-body-sm text-body-sm text-on-surface-variant mt-2 leading-relaxed">
                      Instrumento metodológico construído em conjunto com lideranças indígenas para guiar comunidades na formulação de seus próprios protocolos.
                    </p>
                  </div>
                  <div class="mt-6 pt-4 border-t border-surface-container flex items-center justify-between">
                    <span class="font-label-sm text-label-sm text-clay-warm font-semibold">Produção da Rede</span>
                    <a class="font-label-sm text-label-sm text-primary font-bold hover:underline inline-flex items-center gap-1"
                      href="#">
                      Ver Manual <span class="material-symbols-outlined text-[16px]">chevron_right</span>
                    </a>
                  </div>
                </div>
              </div>
          <?php endif; ?>
        </div>
      </div>
    </section>

    <!-- TRANSIÇÃO FOTOGRÁFICA: FAUNA AQUÁTICA AMAZÔNICA (ARIRANHA) -->
    <div class="relative w-full h-64 sm:h-80 md:h-96 lg:h-[420px] overflow-hidden border-t border-border-subtle bg-earth-dark group">
      <img alt="Ariranha nadando nas águas de rio amazônico"
        class="w-full h-full object-cover object-center transform transition-transform duration-700 ease-out"
        src="<?php echo esc_url(aja_asset('fotos/pexels-jeangc-28587106.png')); ?>" />
      <div class="absolute inset-0 bg-gradient-to-b from-black/10 via-transparent to-black/20 pointer-events-none"></div>
    </div>

    <!-- SECTION 9: CONTATO INSTITUCIONAL ("VAMOS CONVERSAR?") -->
    <section class="w-full py-space-xl bg-surface border-t border-border-subtle" id="contato">
      <div class="max-w-[1440px] mx-auto px-margin-mobile lg:px-margin">
        <div class="bg-surface-container-lowest rounded-2xl p-8 lg:p-14 shadow-sm border border-border-subtle">
          <div class="grid grid-cols-1 lg:grid-cols-12 gap-gutter items-center">
            <div class="lg:col-span-6 flex flex-col gap-4">
              <span class="font-label-sm text-label-sm uppercase tracking-widest text-secondary font-bold">Canais Oficiais</span>
              <h2 class="font-headline-lg text-headline-lg-mobile lg:text-headline-lg text-ink-primary font-medium">
                Vamos Conversar?
              </h2>
              <div class="font-body-md text-body-md text-on-surface-variant max-w-lg leading-relaxed flex flex-col gap-3">
                <p>
                  A Aliança Jurídica pela Amazônia (AJA) valoriza o diálogo e a colaboração com profissionais, organizações e instituições comprometidas com a justiça socioambiental e o fortalecimento do Estado de Direito na Amazônia.
                </p>
                <p>
                  Entre em contato conosco para saber mais sobre nossas iniciativas, parcerias e formas de atuação.
                </p>
              </div>

              <!-- Interactive Links & Contact Channels -->
              <div class="flex flex-col gap-3 mt-4 font-body-sm text-body-sm text-on-surface">
                <!-- Email Sede -->
                <div class="flex items-center gap-3">
                  <span class="w-9 h-9 rounded-lg bg-surface-container flex items-center justify-center text-primary shrink-0">
                    <span class="material-symbols-outlined text-[20px]">mail</span>
                  </span>
                  <div class="flex flex-col">
                    <span class="text-[11px] font-label-sm uppercase tracking-wider text-outline">Sede Institucional</span>
                    <a class="font-medium text-ink-primary hover:text-moss-light transition-colors"
                      href="mailto:sede@ajamazonia.org">sede@ajamazonia.org</a>
                  </div>
                </div>
                <!-- Email Info / Adesão -->
                <div class="flex items-center gap-3">
                  <span class="w-9 h-9 rounded-lg bg-surface-container flex items-center justify-center text-primary shrink-0">
                    <span class="material-symbols-outlined text-[20px]">alternate_email</span>
                  </span>
                  <div class="flex flex-col">
                    <span class="text-[11px] font-label-sm uppercase tracking-wider text-outline">Adesões & Informações</span>
                    <a class="font-medium text-ink-primary hover:text-moss-light transition-colors"
                      href="mailto:info@ajamazonia.org">info@ajamazonia.org</a>
                  </div>
                </div>
                <!-- Instagram -->
                <div class="flex items-center gap-3">
                  <span class="w-9 h-9 rounded-lg bg-surface-container flex items-center justify-center text-primary shrink-0">
                    <svg class="w-5 h-5 fill-current" viewBox="0 0 24 24" aria-hidden="true">
                      <path
                        d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                    </svg>
                  </span>
                  <div class="flex flex-col">
                    <span class="text-[11px] font-label-sm uppercase tracking-wider text-outline">Instagram</span>
                    <a class="font-medium text-ink-primary hover:text-moss-light transition-colors"
                      href="https://www.instagram.com/ajamazonia/" target="_blank"
                      rel="noopener noreferrer">@ajamazonia</a>
                  </div>
                </div>
                <!-- LinkedIn -->
                <div class="flex items-center gap-3">
                  <span class="w-9 h-9 rounded-lg bg-surface-container flex items-center justify-center text-primary shrink-0">
                    <svg class="w-5 h-5 fill-current" viewBox="0 0 24 24" aria-hidden="true">
                      <path
                        d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" />
                    </svg>
                  </span>
                  <div class="flex flex-col">
                    <span class="text-[11px] font-label-sm uppercase tracking-wider text-outline">LinkedIn</span>
                    <a class="font-medium text-ink-primary hover:text-moss-light transition-colors"
                      href="https://www.linkedin.com/company/alian%C3%A7a-jur%C3%ADdica-pela-amaz%C3%B4nia/?originalSubdomain=br" target="_blank"
                      rel="noopener noreferrer">Aliança Jurídica pela Amazônia</a>
                  </div>
                </div>
                <!-- Polos -->
                <div class="flex items-center gap-3">
                  <span class="w-9 h-9 rounded-lg bg-surface-container flex items-center justify-center text-primary shrink-0">
                    <span class="material-symbols-outlined text-[20px]">pin_drop</span>
                  </span>
                  <div class="flex flex-col">
                    <span class="text-[11px] font-label-sm uppercase tracking-wider text-outline">Polos Regionais</span>
                    <span class="font-medium text-ink-primary">Belém (PA), Manaus (AM) e Brasília (DF)</span>
                  </div>
                </div>
              </div>
            </div>

            <!-- Newsletter Box -->
            <div class="lg:col-span-6 mt-6 lg:mt-0">
              <div class="bg-surface-container-low p-6 lg:p-8 rounded-xl flex flex-col gap-4 border border-border-subtle">
                <span class="font-title-md text-title-md font-bold text-ink-primary">Boletim Territorial AJA</span>
                <p class="font-body-sm text-body-sm text-on-surface-variant">
                  Assine para receber análises jurídicas exclusivas, notas técnicas sobre julgamentos ambientais e convocações para chamadas da rede.
                </p>
                <div class="flex flex-col sm:flex-row gap-2 mt-2">
                  <input
                    class="flex-1 h-12 px-4 rounded-lg bg-surface-container-lowest text-on-surface font-body-md focus:outline-none focus:ring-1 focus:ring-primary border border-border-subtle"
                    placeholder="Seu e-mail profissional" type="email" />
                  <button
                    class="h-12 px-6 rounded-lg bg-primary hover:bg-moss-light text-on-primary font-label-md text-label-md uppercase tracking-wider transition-colors shrink-0 font-bold"
                    type="button">
                    Cadastrar
                  </button>
                </div>
                <span class="font-label-sm text-label-sm text-outline">
                  Garantimos a privacidade dos dados nos moldes da LGPD.
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

  </div>
</main>

<?php
get_footer();
