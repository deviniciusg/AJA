<?php
/**
 * Aliança Jurídica pela Amazônia (AJA) - functions.php
 *
 * Configurações do tema, suporte a recursos do WordPress,
 * criação automática das 3 categorias (portfolio, editais, publicações),
 * metaboxes para campos personalizados e enfileiramento de scripts/estilos.
 */

if (!defined('ABSPATH')) {
    exit; // Segurança contra acesso direto
}

/**
 * 1. Configurações iniciais do tema
 */
function aja_theme_setup() {
    // Suporte ao título dinâmico na aba do navegador
    add_theme_support('title-tag');

    // Suporte a miniaturas (Featured Images) em postagens e páginas
    add_theme_support('post-thumbnails');

    // Suporte a logo personalizada
    add_theme_support('custom-logo', array(
        'height'      => 80,
        'width'       => 80,
        'flex-height' => true,
        'flex-width'  => true,
    ));

    // Suporte a HTML5 para formulários e galerias
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script'
    ));

    // Suporte a blocos responsivos
    add_theme_support('responsive-embeds');

    // Registro de Menus de Navegação
    register_nav_menus(array(
        'primary' => __('Menu Principal', 'aja'),
        'footer'  => __('Menu Rodapé', 'aja'),
    ));

    // Tamanhos de imagem personalizados para os cards do tema
    add_image_size('aja-card-thumb', 600, 420, true);
    add_image_size('aja-square-thumb', 400, 400, true);
    add_image_size('aja-banner', 1200, 600, true);
}
add_action('after_setup_theme', 'aja_theme_setup');

/**
 * 2. Enfileiramento de Scripts e Estilos
 */
function aja_enqueue_assets() {
    // Fontes do Google: Epilogue e Material Symbols Outlined
    wp_enqueue_style(
        'google-fonts-epilogue-icons',
        'https://fonts.googleapis.com/css2?family=Epilogue:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200&display=swap',
        array(),
        null
    );

    // Tailwind CSS via CDN oficial
    wp_enqueue_script(
        'tailwindcss',
        'https://cdn.tailwindcss.com',
        array(),
        '3.4.0',
        false // Carrega no <head> para que as classes Tailwind sejam interpretadas
    );

    // Folha de estilos principal do tema
    wp_enqueue_style(
        'aja-style',
        get_stylesheet_uri(),
        array(),
        '1.0.0'
    );

    // Script customizado do tema (Menu mobile, filtros de abas, smooth scroll)
    wp_enqueue_script(
        'aja-main',
        get_template_directory_uri() . '/assets/js/main.js',
        array(),
        '1.0.0',
        true
    );
}
add_action('wp_enqueue_scripts', 'aja_enqueue_assets');

/**
 * 3. Injeção da Configuração do Tailwind no <head>
 */
function aja_tailwind_inline_config() {
    ?>
    <script id="tailwind-config">
      tailwind.config = {
        darkMode: "class",
        theme: {
          extend: {
            colors: {
              "moss-light": "#6f7740",
              "on-secondary-container": "#741d1d",
              "on-tertiary": "#ffffff",
              "ink-primary": "#202115",
              "on-secondary-fixed": "#410004",
              "surface-container": "#ede8e1",
              "inverse-primary": "#c6ca96",
              "on-tertiary-container": "#f8be51",
              "on-error": "#ffffff",
              "surface-tint": "#5d6136",
              "on-primary-fixed": "#1a1d00",
              "surface-container-highest": "#e5e2de",
              "primary-fixed": "#e3e7b0",
              "background": "#fcf9f5",
              "on-secondary": "#ffffff",
              "inverse-surface": "#31302e",
              "tertiary-fixed": "#ffdeaa",
              "outline-variant": "#c8c7b9",
              "tertiary-container": "#6f4d00",
              "on-tertiary-fixed": "#271900",
              "secondary": "#a13e3b",
              "on-surface-variant": "#47473c",
              "surface-container-low": "#f5f1eb",
              "border-subtle": "#e2ded7",
              "secondary-fixed": "#ffdad7",
              "surface-container-lowest": "#ffffff",
              "cyan-accent": "#00d3fc",
              "secondary-fixed-dim": "#ffb3ae",
              "surface-container-high": "#ebe8e4",
              "on-background": "#1c1c1a",
              "on-primary": "#ffffff",
              "on-error-container": "#93000a",
              "outline": "#78786b",
              "primary": "#3b3f17",
              "inverse-on-surface": "#f3f0ec",
              "canvas-paper": "#f7f4f0",
              "on-secondary-fixed-variant": "#812726",
              "on-surface": "#1c1c1a",
              "tertiary": "#513700",
              "surface-dim": "#dcdad6",
              "error": "#ba1a1a",
              "earth-dark": "#431d11",
              "clay-warm": "#825748",
              "error-container": "#ffdad6",
              "on-tertiary-fixed-variant": "#5f4100",
              "surface": "#fcf9f5",
              "tertiary-fixed-dim": "#f7bd50",
              "primary-fixed-dim": "#c6ca96",
              "primary-container": "#52562c",
              "river-sky": "#a6bfe2",
              "secondary-container": "#fe857f",
              "on-primary-fixed-variant": "#464a21",
              "on-primary-container": "#c7cb96",
              "surface-variant": "#e5e2de",
              "surface-bright": "#fcf9f5"
            },
            borderRadius: {
              "DEFAULT": "0.125rem",
              "lg": "0.25rem",
              "xl": "0.5rem",
              "full": "0.75rem"
            },
            spacing: {
              "space-xl": "3rem",
              "margin": "3rem",
              "space-xs": "0.25rem",
              "space-sm": "0.5rem",
              "gutter-mobile": "1rem",
              "space-md": "1rem",
              "margin-mobile": "1.25rem",
              "gutter": "1.5rem",
              "space-lg": "1.75rem"
            },
            fontFamily: {
              "body-lg": ["Epilogue", "sans-serif"],
              "body-sm": ["Epilogue", "sans-serif"],
              "display-lg": ["Epilogue", "sans-serif"],
              "label-lg": ["Epilogue", "sans-serif"],
              "label-md": ["Epilogue", "sans-serif"],
              "headline-md": ["Epilogue", "sans-serif"],
              "display-lg-mobile": ["Epilogue", "sans-serif"],
              "headline-lg": ["Epilogue", "sans-serif"],
              "title-lg": ["Epilogue", "sans-serif"],
              "headline-lg-mobile": ["Epilogue", "sans-serif"],
              "body-md": ["Epilogue", "sans-serif"],
              "title-md": ["Epilogue", "sans-serif"],
              "label-sm": ["Epilogue", "sans-serif"],
              "headline-sm": ["Epilogue", "sans-serif"]
            },
            fontSize: {
              "body-lg": ["18px", { lineHeight: "28px", fontWeight: "400" }],
              "body-sm": ["13px", { lineHeight: "20px", fontWeight: "400" }],
              "display-lg": ["56px", { lineHeight: "64px", letterSpacing: "-0.03em", fontWeight: "600" }],
              "label-lg": ["13px", { lineHeight: "18px", letterSpacing: "0.04em", fontWeight: "600" }],
              "label-md": ["11px", { lineHeight: "16px", letterSpacing: "0.08em", fontWeight: "600" }],
              "headline-md": ["28px", { lineHeight: "36px", letterSpacing: "-0.01em", fontWeight: "500" }],
              "display-lg-mobile": ["38px", { lineHeight: "44px", letterSpacing: "-0.02em", fontWeight: "600" }],
              "headline-lg": ["40px", { lineHeight: "48px", letterSpacing: "-0.02em", fontWeight: "500" }],
              "title-lg": ["19px", { lineHeight: "26px", fontWeight: "600" }],
              "headline-lg-mobile": ["30px", { lineHeight: "36px", letterSpacing: "-0.01em", fontWeight: "500" }],
              "body-md": ["15px", { lineHeight: "24px", fontWeight: "400" }],
              "title-md": ["17px", { lineHeight: "24px", fontWeight: "500" }],
              "label-sm": ["10px", { lineHeight: "14px", letterSpacing: "0.1em", fontWeight: "600" }],
              "headline-sm": ["22px", { lineHeight: "28px", fontWeight: "600" }]
            }
          }
        }
      };
    </script>
    <?php
}
add_action('wp_head', 'aja_tailwind_inline_config', 20);

/**
 * 4. Criação e Configuração Automática das 3 Categorias Solicitadas
 *    - "portfolio"  (Nome: Portfólio, Slug: portfolio)
 *    - "editais"    (Nome: Editais, Slug: editais)
 *    - "publicacoes" (Nome: Publicações, Slug: publicacoes)
 */
function aja_register_required_categories() {
    $required_categories = array(
        'portfolio' => array(
            'cat_name'             => 'Portfólio',
            'category_description' => 'Membros da rede, coletivos, clínicas e iniciativas do portfólio da AJA',
            'category_nicename'    => 'portfolio',
        ),
        'editais' => array(
            'cat_name'             => 'Editais',
            'category_description' => 'Chamadas públicas para artigos, editais e oportunidades contínuas da AJA',
            'category_nicename'    => 'editais',
        ),
        'publicacoes' => array(
            'cat_name'             => 'Publicações',
            'category_description' => 'Notas técnicas, dossiês jurídicos, manuais, artigos e pareceres da AJA',
            'category_nicename'    => 'publicacoes',
        ),
    );

    foreach ($required_categories as $slug => $data) {
        $term_by_slug = get_term_by('slug', $slug, 'category');
        $term_by_name = get_term_by('name', $data['cat_name'], 'category');

        if (!$term_by_slug && !$term_by_name) {
            wp_insert_term(
                $data['cat_name'],
                'category',
                array(
                    'description' => $data['category_description'],
                    'slug'        => $data['category_nicename'],
                )
            );
        }
    }
}
add_action('init', 'aja_register_required_categories');

/**
 * 5. Metabox para Campos Personalizados dos Posts AJA
 *    Permite configurar os campos específicos de cada seção:
 *    - Portfólio: Categoria de filtro (advocacia, pesquisa, sociedade, diretoria) e Localização/GT
 *    - Editais: Selo de status, Destinatário, Link/E-mail do edital
 *    - Publicações: Tipo/Selo (Nota Técnica, Dossiê, Guia), GT associado, Link do arquivo/artigo
 */
function aja_register_post_metaboxes() {
    add_meta_box(
        'aja_post_settings',
        'Configurações da Publicação AJA (Portfólio, Editais ou Publicações)',
        'aja_render_post_metabox',
        'post',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'aja_register_post_metaboxes');

function aja_render_post_metabox($post) {
    wp_nonce_field('aja_save_post_meta', 'aja_post_meta_nonce');

    $badge           = get_post_meta($post->ID, '_aja_badge', true);
    $subtitle_gt     = get_post_meta($post->ID, '_aja_subtitle_gt', true);
    $portfolio_cat   = get_post_meta($post->ID, '_aja_portfolio_category', true);
    $action_link     = get_post_meta($post->ID, '_aja_action_link', true);
    $action_label    = get_post_meta($post->ID, '_aja_action_label', true);
    $featured_edital = get_post_meta($post->ID, '_aja_featured_edital', true);
    ?>
    <div style="font-family: inherit; line-height: 1.5; padding: 10px 0;">
        <p style="color: #666; font-size: 13px; margin-bottom: 15px;">
            Preencha os campos abaixo de acordo com a categoria desta postagem. Os dados alimentarão os cards na Página Inicial da AJA.
        </p>

        <div style="margin-bottom: 14px;">
            <label for="aja_badge" style="display:block; font-weight:600; margin-bottom:4px;">
                Selo / Badge Superior:
            </label>
            <input type="text" id="aja_badge" name="aja_badge" value="<?php echo esc_attr($badge); ?>" style="width: 100%; max-width: 500px;" placeholder="Ex: Advocacia Popular, Nota Técnica, Chamada Aberta, Dossiê Jurídico">
            <span style="display:block; font-size:12px; color:#777; margin-top:2px;">Exibido no topo do card (destaque colorido).</span>
        </div>

        <div style="margin-bottom: 14px;">
            <label for="aja_subtitle_gt" style="display:block; font-weight:600; margin-bottom:4px;">
                Subtítulo / GT / Localização:
            </label>
            <input type="text" id="aja_subtitle_gt" name="aja_subtitle_gt" value="<?php echo esc_attr($subtitle_gt); ?>" style="width: 100%; max-width: 500px;" placeholder="Ex: GT 03 • Finanças Sustentáveis, Estado / Região • GT, Destinada aos Membros da AJA">
            <span style="display:block; font-size:12px; color:#777; margin-top:2px;">Aparece abaixo do título ou no rodapé do card com ícone de localização.</span>
        </div>

        <hr style="border:0; border-top:1px solid #ddd; margin:16px 0;">

        <div style="margin-bottom: 14px;">
            <label for="aja_portfolio_category" style="display:block; font-weight:600; margin-bottom:4px;">
                Se esta postagem for da categoria "Portfólio", escolha a aba de filtro:
            </label>
            <select id="aja_portfolio_category" name="aja_portfolio_category" style="width: 100%; max-width: 500px;">
                <option value="all" <?php selected($portfolio_cat, 'all'); ?>>Todos os Membros (Geral)</option>
                <option value="advocacia" <?php selected($portfolio_cat, 'advocacia'); ?>>Advocacia Popular & Coletivos</option>
                <option value="pesquisa" <?php selected($portfolio_cat, 'pesquisa'); ?>>Pesquisa & Clínicas Jurídicas</option>
                <option value="sociedade" <?php selected($portfolio_cat, 'sociedade'); ?>>Organizações da Sociedade Civil</option>
                <option value="diretoria" <?php selected($portfolio_cat, 'diretoria'); ?>>Articulação & Conselho</option>
            </select>
            <span style="display:block; font-size:12px; color:#777; margin-top:2px;">Define em qual filtro interativo este membro/instituição será exibido.</span>
        </div>

        <hr style="border:0; border-top:1px solid #ddd; margin:16px 0;">

        <div style="margin-bottom: 14px;">
            <label for="aja_action_link" style="display:block; font-weight:600; margin-bottom:4px;">
                Link Personalizado de Ação / Edital / Arquivo PDF:
            </label>
            <input type="text" id="aja_action_link" name="aja_action_link" value="<?php echo esc_attr($action_link); ?>" style="width: 100%; max-width: 500px;" placeholder="Ex: mailto:info@ajamazonia.org ou https://exemplo.org/edital.pdf">
            <span style="display:block; font-size:12px; color:#777; margin-top:2px;">Se deixado em branco, direcionará para a página individual do próprio post no WordPress.</span>
        </div>

        <div style="margin-bottom: 14px;">
            <label for="aja_action_label" style="display:block; font-weight:600; margin-bottom:4px;">
                Texto do Botão / Link de Ação:
            </label>
            <input type="text" id="aja_action_label" name="aja_action_label" value="<?php echo esc_attr($action_label); ?>" style="width: 100%; max-width: 500px;" placeholder="Ex: Ver Parecer, Acessar Edital & Submissão, Ver Dossiê, Manifestar Interesse">
        </div>

        <div style="margin-bottom: 8px;">
            <label style="display:inline-flex; align-items:center; gap:6px; font-weight:600; cursor:pointer;">
                <input type="checkbox" name="aja_featured_edital" value="1" <?php checked($featured_edital, '1'); ?>>
                Destacar como Edital Principal (Banner Grande na Seção de Editais)
            </label>
        </div>
    </div>
    <?php
}

function aja_save_post_metabox($post_id) {
    if (!isset($_POST['aja_post_meta_nonce']) || !wp_verify_nonce($_POST['aja_post_meta_nonce'], 'aja_save_post_meta')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    if (isset($_POST['aja_badge'])) {
        update_post_meta($post_id, '_aja_badge', sanitize_text_field($_POST['aja_badge']));
    }
    if (isset($_POST['aja_subtitle_gt'])) {
        update_post_meta($post_id, '_aja_subtitle_gt', sanitize_text_field($_POST['aja_subtitle_gt']));
    }
    if (isset($_POST['aja_portfolio_category'])) {
        update_post_meta($post_id, '_aja_portfolio_category', sanitize_text_field($_POST['aja_portfolio_category']));
    }
    if (isset($_POST['aja_action_link'])) {
        update_post_meta($post_id, '_aja_action_link', esc_url_raw($_POST['aja_action_link']));
    }
    if (isset($_POST['aja_action_label'])) {
        update_post_meta($post_id, '_aja_action_label', sanitize_text_field($_POST['aja_action_label']));
    }

    $featured = isset($_POST['aja_featured_edital']) ? '1' : '0';
    update_post_meta($post_id, '_aja_featured_edital', $featured);
}
add_action('save_post', 'aja_save_post_metabox');

/**
 * 6. Funções Utilitárias para Resgate de Informações
 */
function aja_asset($path) {
    return get_template_directory_uri() . '/assets/' . ltrim($path, '/');
}

function aja_get_post_badge($post_id, $default = '') {
    $badge = get_post_meta($post_id, '_aja_badge', true);
    if (!empty($badge)) {
        return $badge;
    }
    $categories = get_the_category($post_id);
    if (!empty($categories)) {
        return $categories[0]->name;
    }
    return $default;
}

function aja_get_post_subtitle($post_id, $default = '') {
    $sub = get_post_meta($post_id, '_aja_subtitle_gt', true);
    return !empty($sub) ? $sub : $default;
}

function aja_get_post_action_link($post_id) {
    $link = get_post_meta($post_id, '_aja_action_link', true);
    return !empty($link) ? $link : get_permalink($post_id);
}

function aja_get_post_action_label($post_id, $default = 'Ver Detalhes') {
    $label = get_post_meta($post_id, '_aja_action_label', true);
    return !empty($label) ? $label : $default;
}

function aja_get_portfolio_cat($post_id) {
    $cat = get_post_meta($post_id, '_aja_portfolio_category', true);
    return !empty($cat) ? $cat : 'all';
}

/**
 * 7. Aviso no Painel do WordPress com Botão de Criação de Postagens de Exemplo
 */
function aja_admin_notice_seeder() {
    if (!current_user_can('manage_options')) {
        return;
    }

    // Processar criação de posts de exemplo quando solicitado pelo botão
    if (isset($_GET['aja_seed_samples']) && $_GET['aja_seed_samples'] === '1') {
        aja_create_sample_posts();
        echo '<div class="notice notice-success is-dismissible"><p><strong>Aliança Jurídica pela Amazônia:</strong> Postagens de exemplo criadas com sucesso nas categorias <em>Portfólio</em>, <em>Editais</em> e <em>Publicações</em>!</p></div>';
        return;
    }

    // Verificar se já existem posts nas 3 categorias
    $portfolio_count = aja_count_category_posts('portfolio');
    $editais_count   = aja_count_category_posts('editais');
    $publicacoes_count = aja_count_category_posts('publicacoes');

    if ($portfolio_count === 0 && $editais_count === 0 && $publicacoes_count === 0) {
        $seed_url = admin_url('index.php?aja_seed_samples=1');
        ?>
        <div class="notice notice-info is-dismissible">
            <p>
                <strong>Bem-vindo ao Tema Aliança Jurídica pela Amazônia (AJA)!</strong><br>
                As 3 categorias (<strong>Portfólio</strong>, <strong>Editais</strong> e <strong>Publicações</strong>) já foram configuradas no seu WordPress.
                Deseja gerar as postagens de demonstração com os textos e imagens originais do modelo?
            </p>
            <p>
                <a href="<?php echo esc_url($seed_url); ?>" class="button button-primary">
                    Gerar Postagens de Demonstração da AJA
                </a>
            </p>
        </div>
        <?php
    }
}
add_action('admin_notices', 'aja_admin_notice_seeder');

function aja_count_category_posts($category_slug) {
    $cat = get_term_by('slug', $category_slug, 'category');
    return $cat ? $cat->count : 0;
}

/**
 * 8. Gerador de Postagens de Exemplo (Turnkey Demo Data)
 */
function aja_create_sample_posts() {
    $portfolio_term = get_term_by('slug', 'portfolio', 'category');
    $editais_term   = get_term_by('slug', 'editais', 'category');
    $publicacoes_term = get_term_by('slug', 'publicacoes', 'category');

    if (!$portfolio_term || !$editais_term || !$publicacoes_term) {
        aja_register_required_categories();
        $portfolio_term = get_term_by('slug', 'portfolio', 'category');
        $editais_term   = get_term_by('slug', 'editais', 'category');
        $publicacoes_term = get_term_by('slug', 'publicacoes', 'category');
    }

    // Amostras de Portfólio
    $portfolio_samples = array(
        array(
            'title'    => 'Maparajuba Advocacia Popular',
            'content'  => 'Assessoria jurídica popular a comunidades tradicionais, quilombolas e ribeirinhas no Pará e Amazônia Oriental, atuando na garantia territorial e direitos socioambientais.',
            'category' => 'advocacia',
            'badge'    => 'Advocacia Popular',
            'subtitle' => 'Pará / Polo Norte • GT 01',
        ),
        array(
            'title'    => 'Comitê Executivo e Conselho Consultivo',
            'content'  => 'Coordenação estratégica da Aliança Jurídica pela Amazônia, integrando atores jurídicos em Brasília e polos regionais para articulação nos tribunais superiores.',
            'category' => 'diretoria',
            'badge'    => 'Articulação & Conselho',
            'subtitle' => 'Brasília (DF) • Gestão Horizontal',
        ),
        array(
            'title'    => 'Clínica de Direitos Humanos e Justiça Socioambiental',
            'content'  => 'Produção acadêmica aplicada, monitoramento de litigância climática e relatórios de observância de salvaguardas territoriais em cooperação com universidades amazônicas.',
            'category' => 'pesquisa',
            'badge'    => 'Pesquisa & Clínicas Jurídicas',
            'subtitle' => 'Amazonas / Polo Ocidental • GT 02',
        ),
        array(
            'title'    => 'Rede Liberdade e Coletivos de Apoio',
            'content'  => 'Defesa da liberdade de manifestação, combate à criminalização de lideranças socioambientais e fortalecimento do Estado Democrático de Direito na região.',
            'category' => 'sociedade',
            'badge'    => 'Organizações da Sociedade Civil',
            'subtitle' => 'Nacional & Amazônia Legal • GT 01',
        ),
    );

    foreach ($portfolio_samples as $item) {
        $post_id = wp_insert_post(array(
            'post_title'   => $item['title'],
            'post_content' => $item['content'],
            'post_excerpt' => $item['content'],
            'post_status'  => 'publish',
            'post_type'    => 'post',
            'post_category'=> array($portfolio_term->term_id),
        ));
        if ($post_id) {
            update_post_meta($post_id, '_aja_badge', $item['badge']);
            update_post_meta($post_id, '_aja_subtitle_gt', $item['subtitle']);
            update_post_meta($post_id, '_aja_portfolio_category', $item['category']);
        }
    }

    // Amostras de Editais
    $editais_samples = array(
        array(
            'title'    => 'Chamada para Submissão de Artigos de Opinião Jurídicos',
            'content'  => 'A Aliança Jurídica pela Amazônia (AJA) torna pública a chamada para submissão de artigos de opinião jurídicos voltados ao fortalecimento do debate sobre justiça, democracia socioambiental e Estado de Direito na Amazônia. A iniciativa é destinada aos membros da AJA e busca reunir contribuições inéditas sobre temas jurídicos contemporâneos.',
            'badge'    => 'Chamada Pública Aberta',
            'subtitle' => 'Destinada aos Membros da AJA',
            'link'     => 'mailto:info@ajamazonia.org?subject=Submissao%20de%20Artigo%20AJA',
            'label'    => 'Acessar Edital & Submissão',
            'featured' => '1',
        ),
        array(
            'title'    => 'Chamada Contínua: Banco de Especialistas em Perícia Ambiental',
            'content'  => 'Credenciamento de peritos independentes, cartógrafos sociais e antropólogos para auxílio pro bono em laudos técnicos de demarcação territorial, licenciamento e combate a crimes ambientais.',
            'badge'    => 'Perícia & Cartografia',
            'subtitle' => 'Credenciamento de Membros • Fluxo Contínuo',
            'link'     => 'mailto:info@ajamazonia.org?subject=Credenciamento%20Banco%20de%20Especialistas',
            'label'    => 'Manifestar Interesse',
            'featured' => '0',
        ),
        array(
            'title'    => 'Proposição de Teses e Memoriais para Tribunais Superiores',
            'content'  => 'Envio de memoriais e notas técnicas fundamentadas para validação e submissão conjunta sob a chancela da AJA perante o Supremo Tribunal Federal (STF) e Superior Tribunal de Justiça (STJ).',
            'badge'    => 'Amicus Curiae',
            'subtitle' => 'Avaliação pelo GT 02 • Fluxo Contínuo',
            'link'     => 'mailto:info@ajamazonia.org?subject=Proposicao%20Amicus%20Curiae%20AJA',
            'label'    => 'Submeter Proposição',
            'featured' => '0',
        ),
    );

    foreach ($editais_samples as $item) {
        $post_id = wp_insert_post(array(
            'post_title'   => $item['title'],
            'post_content' => $item['content'],
            'post_excerpt' => $item['content'],
            'post_status'  => 'publish',
            'post_type'    => 'post',
            'post_category'=> array($editais_term->term_id),
        ));
        if ($post_id) {
            update_post_meta($post_id, '_aja_badge', $item['badge']);
            update_post_meta($post_id, '_aja_subtitle_gt', $item['subtitle']);
            update_post_meta($post_id, '_aja_action_link', $item['link']);
            update_post_meta($post_id, '_aja_action_label', $item['label']);
            update_post_meta($post_id, '_aja_featured_edital', $item['featured']);
        }
    }

    // Amostras de Publicações
    $publicacoes_samples = array(
        array(
            'title'    => 'Salvaguardas Mandatórias para Créditos de Carbono Jurisdicionais na Amazônia',
            'content'  => 'Análise comparativa das regulações estaduais frente aos padrões internacionais de integridade e direitos territoriais dos povos tradicionais e comunidades da floresta.',
            'badge'    => 'Nota Técnica',
            'subtitle' => 'GT 03 • Finanças Sustentáveis',
            'link'     => '#',
            'label'    => 'Ver Parecer',
        ),
        array(
            'title'    => 'A Litigância Climática Brasileira nos Tribunais Superiores: Mapeamento de Julgados',
            'content'  => 'Compilado de acórdãos com teses fixadas sobre prescrição de ilícitos ambientais, recomposição de áreas e tutela preventiva socioecológica perante o STF e STJ.',
            'badge'    => 'Dossiê Jurídico',
            'subtitle' => 'GT 02 • Litigância Estratégica',
            'link'     => '#',
            'label'    => 'Ver Dossiê',
        ),
        array(
            'title'    => 'Protocolos Autônomos de Consulta: Manual de Redação e Validação Jurídica',
            'content'  => 'Instrumento metodológico construído em conjunto com lideranças indígenas para guiar comunidades na formulação de seus próprios protocolos conforme a Convenção 169 da OIT.',
            'badge'    => 'Guia Prático',
            'subtitle' => 'GT 01 • Territórios & PIQCTs',
            'link'     => '#',
            'label'    => 'Ver Manual',
        ),
    );

    foreach ($publicacoes_samples as $item) {
        $post_id = wp_insert_post(array(
            'post_title'   => $item['title'],
            'post_content' => $item['content'],
            'post_excerpt' => $item['content'],
            'post_status'  => 'publish',
            'post_type'    => 'post',
            'post_category'=> array($publicacoes_term->term_id),
        ));
        if ($post_id) {
            update_post_meta($post_id, '_aja_badge', $item['badge']);
            update_post_meta($post_id, '_aja_subtitle_gt', $item['subtitle']);
            update_post_meta($post_id, '_aja_action_link', $item['link']);
            update_post_meta($post_id, '_aja_action_label', $item['label']);
        }
    }
}
