<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
  <meta charset="<?php bloginfo('charset'); ?>" />
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <meta content="web_standard" name="shell-type" />
  <link rel="icon" type="image/png" href="<?php echo esc_url(aja_asset('logos/Prancheta 7@3x-8.png')); ?>" />
  <link href="https://fonts.googleapis.com" rel="preconnect" />
  <link crossorigin="" href="https://fonts.gstatic.com" rel="preconnect" />
  <?php wp_head(); ?>
</head>

<body <?php body_class('bg-surface font-body-md text-on-surface antialiased selection:bg-primary-container selection:text-on-primary'); ?>>
<?php wp_body_open(); ?>

  <!-- HEADER COM NAVEGAÇÃO INSTITUCIONAL -->
  <header class="fixed top-0 left-0 w-full z-50 bg-surface/90 backdrop-blur-md shadow-[0_1px_8px_rgba(0,0,0,0.04)] border-b border-border-subtle/50">
    <div class="h-20 max-w-[1440px] mx-auto px-margin-mobile lg:px-margin flex items-center justify-between">
      <a class="flex items-center gap-space-md group" data-path="inicio" href="<?php echo esc_url(home_url('/')); ?>">
        <img alt="Logotipo AJA" class="w-9 h-9 object-contain rounded" src="<?php echo esc_url(aja_asset('logos/Prancheta 7@3x-8.png')); ?>" />
        <div class="flex flex-col">
          <span class="font-title-lg text-title-lg tracking-tight text-ink-primary font-bold">AJA</span>
          <span class="font-label-sm text-label-sm tracking-widest uppercase text-clay-warm">Aliança Jurídica Amazônia</span>
        </div>
      </a>

      <!-- Menu Principal (Desktop) -->
      <nav class="hidden lg:flex items-center gap-1 xl:gap-2">
        <!-- 1. Sobre nós com Submenu (Nossa História e Atuação) -->
        <div class="relative group">
          <a href="<?php echo is_front_page() ? '#sobre-nos' : esc_url(home_url('/#sobre-nos')); ?>" class="flex items-center gap-1 px-3.5 py-2 font-label-lg text-label-lg text-on-surface-variant hover:text-ink-primary hover:bg-surface-container/60 rounded-lg transition-colors group-hover:text-primary">
            <span>Sobre nós</span>
            <span class="material-symbols-outlined text-[18px] transition-transform duration-200 group-hover:rotate-180">expand_more</span>
          </a>
          <!-- Dropdown Submenu contendo Nossa História e Atuação -->
          <div class="absolute top-full left-0 pt-1.5 hidden group-hover:block z-50">
            <div class="bg-surface-container-lowest rounded-xl shadow-xl border border-border-subtle py-2 min-w-[200px] flex flex-col">
              <a class="px-4 py-2.5 font-label-md text-label-md uppercase tracking-wider text-on-surface-variant hover:text-primary hover:bg-surface-container transition-colors flex items-center gap-2.5"
                href="<?php echo is_front_page() ? '#historia' : esc_url(home_url('/#historia')); ?>">
                <span class="w-1.5 h-1.5 rounded-full bg-secondary"></span>
                <span>Nossa História</span>
              </a>
              <a class="px-4 py-2.5 font-label-md text-label-md uppercase tracking-wider text-on-surface-variant hover:text-primary hover:bg-surface-container transition-colors flex items-center gap-2.5"
                href="<?php echo is_front_page() ? '#atuacao' : esc_url(home_url('/#atuacao')); ?>">
                <span class="w-1.5 h-1.5 rounded-full bg-tertiary"></span>
                <span>Atuação</span>
              </a>
            </div>
          </div>
        </div>

        <!-- 2. Portfólio (Categoria Blog: portfolio) -->
        <a class="px-3.5 py-2 font-label-lg text-label-lg text-on-surface-variant hover:text-ink-primary hover:bg-surface-container/60 rounded-lg transition-colors"
          href="<?php echo is_front_page() ? '#portfolio' : esc_url(home_url('/#portfolio')); ?>">Portfólio</a>

        <!-- 3. Editais (Categoria Blog: editais) -->
        <a class="px-3.5 py-2 font-label-lg text-label-lg text-on-surface-variant hover:text-ink-primary hover:bg-surface-container/60 rounded-lg transition-colors"
          href="<?php echo is_front_page() ? '#editais' : esc_url(home_url('/#editais')); ?>">Editais</a>

        <!-- 4. Publicações (Categoria Blog: publicacoes) -->
        <a class="px-3.5 py-2 font-label-lg text-label-lg text-on-surface-variant hover:text-ink-primary hover:bg-surface-container/60 rounded-lg transition-colors"
          href="<?php echo is_front_page() ? '#conhecimento' : esc_url(home_url('/#conhecimento')); ?>">Publicações</a>
      </nav>

      <!-- 5. FAÇA PARTE (Porta de entrada para quem quer integrar os Grupos Temáticos) -->
      <div class="flex items-center gap-3">
        <div class="hidden sm:flex flex-col items-end">
          <a class="inline-flex items-center justify-center px-5 py-2.5 rounded-lg bg-primary text-on-primary font-label-lg text-label-lg tracking-wider uppercase transition-colors hover:bg-moss-light shadow-sm font-bold group/btn"
            href="<?php echo is_front_page() ? '#faca-parte' : esc_url(home_url('/#faca-parte')); ?>" title="Porta de entrada para quem quer integrar os Grupos Temáticos">
            <span>FAÇA PARTE</span>
            <span class="material-symbols-outlined ml-1.5 text-[18px] group-hover/btn:translate-x-0.5 transition-transform">arrow_forward</span>
          </a>
          <span class="text-[10px] text-on-surface-variant font-label-sm tracking-tight mt-0.5">
            Porta de entrada para integrar os Grupos Temáticos
          </span>
        </div>
        <div class="flex sm:hidden items-center">
          <a class="inline-flex items-center justify-center px-4 py-2 rounded-lg bg-primary text-on-primary font-label-lg text-label-lg tracking-wider uppercase font-bold"
            href="<?php echo is_front_page() ? '#faca-parte' : esc_url(home_url('/#faca-parte')); ?>">
            <span>FAÇA PARTE</span>
          </a>
        </div>
        <button id="mobile-menu-toggle" class="lg:hidden p-2 rounded-lg text-on-surface-variant hover:text-on-surface hover:bg-surface-container transition-colors" aria-label="Abrir menu de navegação">
          <span class="material-symbols-outlined text-[26px]">menu</span>
        </button>
      </div>
    </div>

    <!-- Mobile Navigation Drawer -->
    <div id="mobile-menu" class="hidden lg:hidden bg-surface-container-lowest border-b border-border-subtle px-margin-mobile py-4 shadow-lg flex flex-col gap-2">
      <!-- 1. Sobre nós (com Submenu: Nossa História e Atuação) -->
      <div class="flex flex-col">
        <a href="<?php echo is_front_page() ? '#sobre-nos' : esc_url(home_url('/#sobre-nos')); ?>" class="py-2.5 px-3 rounded-lg text-ink-primary font-bold font-label-lg text-label-lg hover:bg-surface-container transition-colors flex items-center justify-between">
          <span>Sobre nós</span>
          <span class="material-symbols-outlined text-[18px] text-outline">expand_more</span>
        </a>
        <div class="pl-4 flex flex-col border-l-2 border-primary/20 ml-3 my-1 gap-1">
          <a class="py-2 px-3 rounded-md text-on-surface-variant font-label-md text-label-md uppercase tracking-wider hover:text-primary hover:bg-surface-container transition-colors"
            href="<?php echo is_front_page() ? '#historia' : esc_url(home_url('/#historia')); ?>">Nossa História</a>
          <a class="py-2 px-3 rounded-md text-on-surface-variant font-label-md text-label-md uppercase tracking-wider hover:text-primary hover:bg-surface-container transition-colors"
            href="<?php echo is_front_page() ? '#atuacao' : esc_url(home_url('/#atuacao')); ?>">Atuação</a>
        </div>
      </div>

      <!-- 2. Portfólio -->
      <a class="py-2.5 px-3 rounded-lg text-on-surface font-label-lg text-label-lg hover:bg-surface-container transition-colors"
        href="<?php echo is_front_page() ? '#portfolio' : esc_url(home_url('/#portfolio')); ?>">Portfólio</a>

      <!-- 3. Editais -->
      <a class="py-2.5 px-3 rounded-lg text-on-surface font-label-lg text-label-lg hover:bg-surface-container transition-colors"
        href="<?php echo is_front_page() ? '#editais' : esc_url(home_url('/#editais')); ?>">Editais</a>

      <!-- 4. Publicações -->
      <a class="py-2.5 px-3 rounded-lg text-on-surface font-label-lg text-label-lg hover:bg-surface-container transition-colors"
        href="<?php echo is_front_page() ? '#conhecimento' : esc_url(home_url('/#conhecimento')); ?>">Publicações</a>

      <!-- 5. FAÇA PARTE (Destaque mobile com subtítulo: Porta de entrada para integrar os GTs) -->
      <div class="pt-2 border-t border-border-subtle mt-1 flex flex-col gap-1.5">
        <a class="w-full inline-flex items-center justify-center py-3 rounded-lg bg-primary text-on-primary font-label-lg text-label-lg tracking-wider uppercase font-bold shadow-sm"
          href="<?php echo is_front_page() ? '#faca-parte' : esc_url(home_url('/#faca-parte')); ?>">
          FAÇA PARTE
        </a>
        <span class="text-[11px] font-label-sm text-center text-on-surface-variant">
          Porta de entrada para quem quer integrar os Grupos Temáticos
        </span>
      </div>
    </div>
  </header>
