<?php
/**
 * Aliança Jurídica pela Amazônia (AJA) - single.php
 *
 * Modelo de exibição de post individual (Portfólio, Editais ou Publicações).
 */

get_header();

while (have_posts()) : the_post();
    $post_id     = get_the_ID();
    $badge       = aja_get_post_badge($post_id, 'Publicação');
    $subtitle    = aja_get_post_subtitle($post_id, '');
    $action_link = get_post_meta($post_id, '_aja_action_link', true);
    $action_lbl  = aja_get_post_action_label($post_id, 'Acessar Link Externo');
    $categories  = get_the_category($post_id);
    $cat_name    = !empty($categories) ? $categories[0]->name : '';
    $cat_link    = !empty($categories) ? get_category_link($categories[0]->term_id) : '#';
?>

<main class="w-full pt-28 pb-20 bg-surface min-h-[calc(100vh-80px)]">
  <article class="max-w-[1000px] mx-auto px-margin-mobile lg:px-margin">
    
    <!-- Breadcrumb & Categoria -->
    <div class="flex items-center gap-2 text-label-sm font-label-sm uppercase tracking-wider mb-6 text-on-surface-variant">
      <a href="<?php echo esc_url(home_url('/')); ?>" class="hover:text-primary transition-colors">Início</a>
      <span>/</span>
      <?php if (!empty($cat_name)) : ?>
        <a href="<?php echo esc_url($cat_link); ?>" class="hover:text-primary transition-colors text-primary font-bold">
          <?php echo esc_html($cat_name); ?>
        </a>
      <?php endif; ?>
    </div>

    <!-- Cabeçalho do Post -->
    <header class="mb-10 flex flex-col gap-4">
      <div class="flex flex-wrap items-center gap-3">
        <span class="px-3 py-1 rounded bg-secondary-fixed text-on-secondary-fixed font-label-sm text-label-sm font-bold uppercase tracking-wider">
          <?php echo esc_html($badge); ?>
        </span>
        <?php if (!empty($subtitle)) : ?>
          <span class="font-label-sm text-label-sm text-clay-warm font-semibold">
            <?php echo esc_html($subtitle); ?>
          </span>
        <?php endif; ?>
      </div>

      <h1 class="font-headline-lg text-headline-lg-mobile lg:text-headline-lg text-ink-primary font-bold leading-tight">
        <?php the_title(); ?>
      </h1>

      <div class="flex items-center gap-4 text-body-sm font-body-sm text-on-surface-variant pt-2 border-t border-border-subtle">
        <span>Publicado em: <strong><?php echo get_the_date('d/m/Y'); ?></strong></span>
        <span>•</span>
        <span>Por: <strong><?php the_author(); ?></strong></span>
      </div>
    </header>

    <!-- Imagem Destacada (se houver) -->
    <?php if (has_post_thumbnail()) : ?>
      <div class="rounded-2xl overflow-hidden shadow-md mb-10 max-h-[500px]">
        <?php the_post_thumbnail('aja-banner', array('class' => 'w-full h-full object-cover')); ?>
      </div>
    <?php endif; ?>

    <!-- Conteúdo do Post -->
    <div class="prose-aja font-body-lg text-body-md text-on-surface-variant leading-relaxed mb-12 bg-surface-container-lowest p-8 lg:p-12 rounded-2xl border border-border-subtle shadow-sm">
      <?php the_content(); ?>

      <!-- Botão de Ação / Link de Edital / PDF (se preenchido) -->
      <?php if (!empty($action_link)) : ?>
        <div class="mt-8 pt-6 border-t border-border-subtle flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <span class="font-label-md text-label-md uppercase tracking-wider text-primary font-bold block">Documento / Link Vinculado:</span>
            <span class="font-body-sm text-body-sm text-on-surface-variant">Acesse o material de referência ou canal de submissão oficial.</span>
          </div>
          <a href="<?php echo esc_url($action_link); ?>" target="_blank" rel="noopener noreferrer"
            class="px-6 py-3 rounded-lg bg-primary hover:bg-moss-light text-on-primary font-label-md text-label-md uppercase tracking-wider font-bold transition-colors inline-flex items-center gap-2 shrink-0">
            <span><?php echo esc_html($action_lbl); ?></span>
            <span class="material-symbols-outlined text-[18px]">open_in_new</span>
          </a>
        </div>
      <?php endif; ?>
    </div>

    <!-- Navegação e Voltar -->
    <div class="flex items-center justify-between pt-6 border-t border-border-subtle">
      <a href="<?php echo esc_url(home_url('/')); ?>"
        class="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-surface-container hover:bg-surface-container-high text-ink-primary font-label-md text-label-md uppercase tracking-wider transition-colors font-bold">
        <span class="material-symbols-outlined text-[18px]">arrow_back</span>
        Voltar à Página Inicial
      </a>

      <?php if (!empty($cat_name)) : ?>
        <a href="<?php echo esc_url($cat_link); ?>"
          class="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-primary text-on-primary font-label-md text-label-md uppercase tracking-wider hover:bg-moss-light transition-colors font-bold">
          Ver mais em <?php echo esc_html($cat_name); ?>
          <span class="material-symbols-outlined text-[18px]">arrow_forward</span>
        </a>
      <?php endif; ?>
    </div>

  </article>
</main>

<?php
endwhile;

get_footer();
